 import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'dart:math' as math;
 import 'package:url_launcher/url_launcher.dart';
 import 'package:flutter/material.dart';
 // Add this class anywhere in your file (preferably after all the dashboard classes)
 class AlertSystem {
   static Future<void> sendSMS(String message, String phoneNumber) async {
     final Uri smsUri = Uri(
       scheme: 'sms',
       path: phoneNumber,
       queryParameters: {'body': message},
     );

     if (await canLaunchUrl(smsUri)) {
       await launchUrl(smsUri);
     } else {
       throw 'Could not launch SMS';
     }
   }

   static Future<void> sendWhatsApp(String message, String phoneNumber) async {
     // Remove any non-digit characters from phone number
     String formattedNumber = phoneNumber.replaceAll(RegExp(r'[^0-9]'), '');

     final Uri whatsappUri = Uri(
       scheme: 'https',
       host: 'wa.me',
       path: formattedNumber,
       queryParameters: {'text': message},
     );

     if (await canLaunchUrl(whatsappUri)) {
       await launchUrl(whatsappUri);
     } else {
       throw 'Could not launch WhatsApp';
     }
   }

   static Future<void> makeCall(String phoneNumber) async {
     final Uri callUri = Uri(
       scheme: 'tel',
       path: phoneNumber,
     );

     if (await canLaunchUrl(callUri)) {
       await launchUrl(callUri);
     } else {
       throw 'Could not make call';
     }
   }

   static Map<String, String> getAlertTemplates(String userType) {
     switch (userType) {
       case 'health_official':
         return {
           'outbreak_alert': 'URGENT: Disease outbreak detected. Dispatch medical teams immediately.',
           'resource_request': 'Need additional resources for outbreak response.',
           'preventive_measures': 'Initiate preventive measures in high-risk areas.'
         };
       case 'village_leader':
         return {
           'water_contamination': 'WARNING: Water source contaminated. Boil water before use.',
           'community_meeting': 'Emergency community meeting scheduled.',
           'health_alert': 'Health alert: Increased disease cases in village.'
         };
       case 'asha_worker':
         return {
           'symptom_report': 'Multiple cases of symptoms reported in area.',
           'water_test': 'Water test results show contamination.',
           'follow_up': 'Patient follow-up needed for suspected cases.'
         };
       default:
         return {
           'general': 'Important community health announcement.'
         };
     }
   }
 }

 void main() {
runApp(const HealthSurveillanceApp());
}

class HealthSurveillanceApp extends StatelessWidget {
const HealthSurveillanceApp({super.key});

@override
Widget build(BuildContext context) {
return MaterialApp(
title: 'AQUAGUARD - Health Surveillance',
debugShowCheckedModeBanner: false,
theme: ThemeData(
colorScheme: ColorScheme.fromSeed(
seedColor: const Color(0xFF2A7FBA),
primary: const Color(0xFF2A7FBA),
secondary: const Color(0xFF4CAF50),
),
useMaterial3: true,
textTheme: GoogleFonts.interTextTheme(),
),
home: const SplashScreen(), // ⚠️ SplashScreen must be defined
);
}
}
class SplashScreen extends StatefulWidget {
const SplashScreen({super.key});

@override
State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
with TickerProviderStateMixin {
late AnimationController _drawController;
late AnimationController _fadeController;
late AnimationController _taglineController;

late Animation<double> _drawAnimation;
late Animation<double> _fadeAnimation;
late Animation<double> _taglineAnimation;

@override
void initState() {
super.initState();

// "A" drawing animation
_drawController = AnimationController(
vsync: this,
duration: const Duration(seconds: 2),
);

_drawAnimation = CurvedAnimation(
parent: _drawController,
curve: Curves.easeInOutCubic,
);

// Fade in AQUAGUARD text
_fadeController = AnimationController(
vsync: this,
duration: const Duration(milliseconds: 800),
);
_fadeAnimation = CurvedAnimation(
parent: _fadeController,
curve: Curves.easeIn,
);

// Fade in Tagline
_taglineController = AnimationController(
vsync: this,
duration: const Duration(milliseconds: 800),
);
_taglineAnimation = CurvedAnimation(
parent: _taglineController,
curve: Curves.easeIn,
);

// Sequence animations
_drawController.forward().whenComplete(() {
_fadeController.forward().whenComplete(() {
_taglineController.forward();
});
});

// Navigate after splash (extended to 8 seconds total)
Future.delayed(const Duration(seconds: 8), () {
if (mounted) {
Navigator.pushReplacement(
context,
MaterialPageRoute(
builder: (context) => const LanguageSelectionScreen(),
),
);
}
});
}

@override
void dispose() {
_drawController.dispose();
_fadeController.dispose();
_taglineController.dispose();
super.dispose();
}

@override
Widget build(BuildContext context) {
return Scaffold(
body: Container(
decoration: const BoxDecoration(
gradient: LinearGradient(
colors: [Color(0xFF001F3F), Color(0xFF0074D9)], // deep navy → aqua
begin: Alignment.topLeft,
end: Alignment.bottomRight,
),
),
child: Center(
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
// Animated "A"
AnimatedBuilder(
animation: _drawAnimation,
builder: (context, child) {
return CustomPaint(
painter: FancyAPainter(progress: _drawAnimation.value),
size: const Size(200, 200),
);
},
),

const SizedBox(height: 30),

// AQUAGUARD
FadeTransition(
opacity: _fadeAnimation,
child: Text(
"AQUAGUARD",
style: GoogleFonts.montserrat(
fontSize: 42,
fontWeight: FontWeight.bold,
color: Colors.white,
letterSpacing: 6,
shadows: [
Shadow(
blurRadius: 20,
color: Colors.cyanAccent.withValues(alpha: 0.9),
offset: const Offset(0, 0),
),
],
),
),
),

const SizedBox(height: 15),

// HEALTH SURVEILLANCE SYSTEM (tagline)
FadeTransition(
opacity: _taglineAnimation,
child: Text(
"HEALTH SURVEILLANCE SYSTEM",
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.w500,
color: Colors.white.withOpacity(0.9),
letterSpacing: 2,
),
),
),
],
),
),
),
);
}
}

/// Custom Painter to draw glowing Aqua "A"
class FancyAPainter extends CustomPainter {
final double progress; // expected 0.0 - 1.0
FancyAPainter({required this.progress});

@override
void paint(Canvas canvas, Size size) {
final gradient = const LinearGradient(
colors: [Colors.cyanAccent, Colors.blueAccent],
begin: Alignment.topCenter,
end: Alignment.bottomCenter,
);

final rect = Rect.fromLTWH(0, 0, size.width, size.height);
final paint = Paint()
..shader = gradient.createShader(rect)
..strokeWidth = 10
..style = PaintingStyle.stroke
..strokeCap = StrokeCap.round
..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

final path = Path();
final height = size.height;
final width = size.width;

// Stylish "A"
path.moveTo(width * 0.15, height);
path.lineTo(width * 0.5, height * 0.05);
path.lineTo(width * 0.85, height);

path.moveTo(width * 0.32, height * 0.55);
path.lineTo(width * 0.68, height * 0.55);

final p = progress.clamp(0.0, 1.0);

final metrics = path.computeMetrics().toList();
if (metrics.isEmpty) return;

double totalLength = metrics.fold(0, (sum, m) => sum + m.length);

double drawLength = totalLength * p;
final drawnPath = Path();

for (final metric in metrics) {
if (drawLength <= 0) break;
final take = math.min(metric.length, drawLength);
drawnPath.addPath(metric.extractPath(0.0, take), Offset.zero);
drawLength -= take;
}

canvas.drawPath(drawnPath, paint);
}

@override
bool shouldRepaint(covariant FancyAPainter old) =>
old.progress != progress;
}

// ---------------------- NEXT SCREEN ----------------------

class LanguageSelectionScreen extends StatefulWidget {
const LanguageSelectionScreen({super.key});

@override
State<LanguageSelectionScreen> createState() => _LanguageSelectionScreenState();
}

class _LanguageSelectionScreenState extends State<LanguageSelectionScreen> {
String _selectedLanguage = 'English';
bool _offlineMode = false;

// Complete list of 25 languages as requested
final List<Map<String, String>> languages = [
{'code': 'en', 'name': 'English', 'nativeName': 'English'},
{'code': 'hi', 'name': 'Hindi', 'nativeName': 'हिन्दी'},
{'code': 'as', 'name': 'Assamese', 'nativeName': 'অসমীয়া'},
{'code': 'bn', 'name': 'Bengali', 'nativeName': 'বাংলা'},
{'code': 'mni', 'name': 'Manipuri/Meitei', 'nativeName': 'ꯃꯩꯇꯩꯂꯣꯟ'},
{'code': 'kha', 'name': 'Khasi', 'nativeName': 'Khasi'},
{'code': 'gar', 'name': 'Garo', 'nativeName': 'Garo'},
{'code': 'lus', 'name': 'Mizo (Lushai)', 'nativeName': 'Mizo'},
{'code': 'brx', 'name': 'Bodo', 'nativeName': 'बर\' / बड़ो'},
{'code': 'ne', 'name': 'Nepali', 'nativeName': 'नेपाली'},
{'code': 'aao', 'name': 'Ao Naga', 'nativeName': 'Ao Naga'},
{'code': 'njm', 'name': 'Angami Naga', 'nativeName': 'Angami Naga'},
{'code': 'nsm', 'name': 'Sumi Naga', 'nativeName': 'Sumi Naga'},
{'code': 'nmf', 'name': 'Tangkhul', 'nativeName': 'Tangkhul'},
{'code': 'mrg', 'name': 'Mishing', 'nativeName': 'Mishing'},
{'code': 'trp', 'name': 'Kokborok (Tripuri)', 'nativeName': 'Kokborok'},
{'code': 'mop', 'name': 'Monpa', 'nativeName': 'Monpa'},
{'code': 'njz', 'name': 'Nyishi', 'nativeName': 'Nyishi'},
{'code': 'adi', 'name': 'Adi', 'nativeName': 'Adi'},
{'code': 'clk', 'name': 'Mishmi (Idu)', 'nativeName': 'Mishmi'},
{'code': 'nnp', 'name': 'Wancho', 'nativeName': 'Wancho'},
{'code': 'njb', 'name': 'Nocte', 'nativeName': 'Nocte'},
{'code': 'nbe', 'name': 'Konyak', 'nativeName': 'Konyak'},
{'code': 'kht', 'name': 'Khamti', 'nativeName': 'Khamti'},
{'code': 'sgk', 'name': 'Sangtam Naga', 'nativeName': 'Sangtam Naga'},
];

@override
Widget build(BuildContext context) {
return Scaffold(
body: Container(
decoration: const BoxDecoration(
gradient: LinearGradient(
begin: Alignment.topCenter,
end: Alignment.bottomCenter,
colors: [
Color(0xFF0D47A1),
Color(0xFF1976D2),
Color(0xFF42A5F5),
],
),
),
child: Padding(
padding: const EdgeInsets.all(20.0),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
// App Name - Fixed to be fully visible
const SizedBox(height: 10),
Text(
'AQUAGUARD',
style: GoogleFonts.poppins(
fontSize: 36,
fontWeight: FontWeight.w800,
color: Colors.white,
letterSpacing: 2.0,
),
),

const SizedBox(height: 10),

// Tagline
Text(
'Health Surveillance System',
style: GoogleFonts.poppins(
fontSize: 16,
fontWeight: FontWeight.w500,
color: Colors.white.withOpacity(0.9),
),
),

const SizedBox(height: 30),

// Language Selection Title
Text(
'Select Your Language',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: Colors.white,
),
),

const SizedBox(height: 15),

// Language List with search functionality
Expanded(
child: Column(
children: [
// Search bar
Container(
decoration: BoxDecoration(
color: Colors.white.withOpacity(0.2),
borderRadius: BorderRadius.circular(12),
),
child: TextField(
decoration: InputDecoration(
hintText: 'Search language...',
hintStyle: GoogleFonts.poppins(color: Colors.white70),
prefixIcon: const Icon(Icons.search, color: Colors.white70),
border: InputBorder.none,
contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
),
style: GoogleFonts.poppins(color: Colors.white),
onChanged: (value) {
// Implement search functionality here
},
),
),

const SizedBox(height: 15),

// Language list
Expanded(
child: ListView.builder(
itemCount: languages.length,
itemBuilder: (context, index) {
final language = languages[index];
return Card(
color: _selectedLanguage == language['name']
? Colors.white.withOpacity(0.9)
    : Colors.white.withOpacity(0.7),
margin: const EdgeInsets.symmetric(vertical: 6),
child: ListTile(
leading: const Icon(Icons.language, color: Color(0xFF0D47A1)),
title: Text(
language['name']!,
style: GoogleFonts.poppins(
fontWeight: FontWeight.w600,
color: const Color(0xFF0D47A1),
),
),
subtitle: Text(
language['nativeName']!,
style: GoogleFonts.poppins(
color: const Color(0xFF0D47A1),
),
),
trailing: _selectedLanguage == language['name']
? const Icon(Icons.check_circle, color: Color(0xFF0D47A1))
    : null,
onTap: () {
setState(() {
_selectedLanguage = language['name']!;
});
},
),
);
},
),
),
],
),
),

const SizedBox(height: 20),

// Offline Mode Toggle
Card(
color: Colors.white.withOpacity(0.7),
child: SwitchListTile(
title: Text(
'Offline Mode',
style: GoogleFonts.poppins(
fontWeight: FontWeight.w600,
color: const Color(0xFF0D47A1),
),
),
subtitle: Text(
'Enable for areas with limited connectivity',
style: GoogleFonts.poppins(
color: const Color(0xFF0D47A1),
),
),
value: _offlineMode,
onChanged: (value) {
setState(() {
_offlineMode = value;
});
},
activeColor: Colors.black,
),
),

const SizedBox(height: 25),

// Continue Button
SizedBox(
width: double.infinity,
child: ElevatedButton(
onPressed: () {
// Save language and offline mode preferences
// Then navigate to the next screen
Navigator.of(context).pushReplacement(
MaterialPageRoute(builder: (context) => const UserPortalScreen()),
);
},
style: ElevatedButton.styleFrom(
backgroundColor: Colors.white,
foregroundColor: const Color(0xFF0D47A1),
padding: const EdgeInsets.symmetric(vertical: 16),
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(12),
),
elevation: 5,
),
child: Text(
'Continue',
style: GoogleFonts.poppins(
fontSize: 16,
fontWeight: FontWeight.bold,
),
),
),
),
],
),
),
),
);
}
}
 class UserPortalScreen extends StatefulWidget {
   const UserPortalScreen({super.key});

   @override
   State<UserPortalScreen> createState() => _UserPortalScreenState();
 }

 class _UserPortalScreenState extends State<UserPortalScreen> {
   final Map<String, String> _userCredentials = {
     'asha_worker': 'asha123',
     'village_leader': 'leader123',
     'health_official': 'official123',
     'community_member': 'community123',
   };

   String _selectedPortal = '';
   final TextEditingController _usernameController = TextEditingController();
   final TextEditingController _passwordController = TextEditingController();
   bool _isLoading = false;
   String _errorMessage = '';

   @override
   Widget build(BuildContext context) {
     return Scaffold(
       resizeToAvoidBottomInset: true,
       body: Container(
         decoration: const BoxDecoration(
           gradient: LinearGradient(
             begin: Alignment.topCenter,
             end: Alignment.bottomCenter,
             colors: [
               Color(0xFF0D47A1),
               Color(0xFF1976D2),
               Color(0xFF42A5F5),
             ],
           ),
         ),
         child: SafeArea(
           child: SingleChildScrollView(
             child: Padding(
               padding: const EdgeInsets.all(20.0),
               child: Column(
                 crossAxisAlignment: CrossAxisAlignment.center,
                 children: [
                   // App Name
                   Text(
                     'AQUAGUARD',
                     style: GoogleFonts.poppins(
                       fontSize: 36,
                       fontWeight: FontWeight.w800,
                       color: Colors.white,
                       letterSpacing: 2.0,
                     ),
                   ),

                   const SizedBox(height: 8),

                   // Tagline
                   Text(
                     'Select Your Portal',
                     style: GoogleFonts.poppins(
                       fontSize: 16,
                       fontWeight: FontWeight.w500,
                       color: Colors.white.withOpacity(0.9),
                     ),
                   ),

                   const SizedBox(height: 24),

                   // Portal Selection Title
                   Text(
                     'Choose Your Access Portal',
                     style: GoogleFonts.poppins(
                       fontSize: 22,
                       fontWeight: FontWeight.bold,
                       color: Colors.white,
                     ),
                   ),

                   const SizedBox(height: 16),

                   // ✅ Compact Grid (always 2 per row, even on laptop)
                   Center(
                     child: ConstrainedBox(
                       constraints: const BoxConstraints(maxWidth: 700),
                       child: GridView.count(
                         shrinkWrap: true,
                         physics: const NeverScrollableScrollPhysics(),
                         crossAxisCount: 2,
                         crossAxisSpacing: 12,
                         mainAxisSpacing: 12,
                         childAspectRatio: 1.05,
                         padding: const EdgeInsets.symmetric(horizontal: 8),
                         children: [
                           _buildPortalCard(
                             'ASHA Workers',
                             Icons.medical_services,
                             [Colors.greenAccent, Colors.green],
                             'asha_worker',
                           ),
                           _buildPortalCard(
                             'Village Leaders',
                             Icons.groups,
                             [Colors.orangeAccent, Colors.deepOrange],
                             'village_leader',
                           ),
                           _buildPortalCard(
                             'Health Officials',
                             Icons.analytics,
                             [Colors.purpleAccent, Colors.deepPurple],
                             'health_official',
                           ),
                           _buildPortalCard(
                             'Community Members',
                             Icons.people,
                             [Colors.redAccent, Colors.red],
                             'community_member',
                           ),
                         ],
                       ),
                     ),
                   ),

                   const SizedBox(height: 24),

                   // ✨ Highlights Section
                   Text(
                     "Why AquaGuard?",
                     style: GoogleFonts.poppins(
                       fontSize: 20,
                       fontWeight: FontWeight.bold,
                       color: Colors.white,
                     ),
                   ),
                   const SizedBox(height: 12),
                   Wrap(
                     spacing: 16,
                     runSpacing: 16,
                     alignment: WrapAlignment.center,
                     children: [
                       _buildFeatureCard(Icons.water_drop, "Clean Water Access",
                           [Colors.lightBlueAccent, Colors.blue]),
                       _buildFeatureCard(Icons.health_and_safety,
                           "Health Monitoring", [Colors.greenAccent, Colors.green]),
                       _buildFeatureCard(Icons.notifications_active,
                           "Instant Alerts", [Colors.orangeAccent, Colors.deepOrange]),
                       _buildFeatureCard(Icons.insights, "Analytics & Reports",
                           [Colors.purpleAccent, Colors.deepPurple]),
                       _buildFeatureCard(Icons.group, "Community Support",
                           [Colors.pinkAccent, Colors.red]),
                     ],
                   ),

                   const SizedBox(height: 16),

                   // ✅ Login Form (only when portal selected)
                   if (_selectedPortal.isNotEmpty) _buildLoginForm(),

                   const SizedBox(height: 10),
                 ],
               ),
             ),
           ),
         ),
       ),
     );
   }

   Widget _buildPortalCard(
       String title, IconData icon, List<Color> colors, String portalKey) {
     final bool isSelected = _selectedPortal == portalKey;

     return Card(
       elevation: 6,
       shape: RoundedRectangleBorder(
         borderRadius: BorderRadius.circular(14),
       ),
       child: InkWell(
         borderRadius: BorderRadius.circular(14),
         onTap: () {
           setState(() {
             _selectedPortal = portalKey;
             _errorMessage = '';
           });
         },
         child: Container(
           decoration: BoxDecoration(
             gradient: LinearGradient(
               colors: isSelected ? colors : [Colors.white, Colors.white70],
               begin: Alignment.topLeft,
               end: Alignment.bottomRight,
             ),
             borderRadius: BorderRadius.circular(14),
             border: isSelected
                 ? Border.all(color: colors.last, width: 2)
                 : Border.all(color: Colors.transparent),
           ),
           child: Center(
             child: Column(
               mainAxisAlignment: MainAxisAlignment.center,
               children: [
                 Icon(icon,
                     size: 30, color: isSelected ? Colors.white : colors.last),
                 const SizedBox(height: 8),
                 Text(
                   title,
                   textAlign: TextAlign.center,
                   style: GoogleFonts.poppins(
                     fontSize: 13,
                     fontWeight: FontWeight.w600,
                     color: isSelected ? Colors.white : const Color(0xFF0D47A1),
                   ),
                 ),
               ],
             ),
           ),
         ),
       ),
     );
   }
   Widget _buildFeatureCard(IconData icon, String title, List<Color> colors) {
     return InkWell(
       borderRadius: BorderRadius.circular(16),
       onTap: () {
         _showFeatureDialog(title);
       },
       child: Container(
         width: 160,
         padding: const EdgeInsets.all(16),
         decoration: BoxDecoration(
           gradient: LinearGradient(
             colors: colors,
             begin: Alignment.topLeft,
             end: Alignment.bottomRight,
           ),
           borderRadius: BorderRadius.circular(16),
           boxShadow: [
             BoxShadow(
               color: colors.last.withOpacity(0.4),
               blurRadius: 8,
               offset: const Offset(2, 4),
             ),
           ],
         ),
         child: Column(
           mainAxisSize: MainAxisSize.min,
           children: [
             Icon(icon, size: 32, color: Colors.white),
             const SizedBox(height: 10),
             Text(
               title,
               textAlign: TextAlign.center,
               style: GoogleFonts.poppins(
                 fontSize: 14,
                 fontWeight: FontWeight.w600,
                 color: Colors.white,
               ),
             ),
           ],
         ),
       ),
     );
   }


   void _showFeatureDialog(String feature) {
     String description = "";
     switch (feature) {
       case "Clean Water Access":
         description =
         "Ensures safe and reliable access to clean drinking water for all communities.";
         break;
       case "Health Monitoring":
         description =
         "Tracks community health statistics, detects issues early, and provides preventive measures.";
         break;
       case "Instant Alerts":
         description =
         "Sends real-time alerts for emergencies like water contamination, disease outbreaks, and health hazards.";
         break;
       case "Analytics & Reports":
         description =
         "Provides detailed insights, data analytics, and visual reports to help officials make better decisions.";
         break;
       case "Community Support":
         description =
         "Encourages collaboration between health workers, leaders, and community members for problem solving.";
         break;
     }

     showDialog(
       context: context,
       builder: (context) => AlertDialog(
         shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.circular(16),
         ),
         title: Text(feature,
             style: GoogleFonts.poppins(
                 fontSize: 18,
                 fontWeight: FontWeight.bold,
                 color: const Color(0xFF0D47A1))),
         content: Text(description,
             style: GoogleFonts.poppins(
                 fontSize: 14, color: Colors.black87)),
         actions: [
           TextButton(
             onPressed: () => Navigator.pop(context),
             child: const Text("Back"),
           )
         ],
       ),
     );
   }


   Widget _buildLoginForm() {
     return Card(
       color: Colors.white.withOpacity(0.95),
       elevation: 5,
       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
       child: Padding(
         padding: const EdgeInsets.all(16.0),
         child: Column(
           mainAxisSize: MainAxisSize.min,
           children: [
             Text(
               'Login to ${_getPortalName(_selectedPortal)} Portal',
               style: GoogleFonts.poppins(
                 fontSize: 18,
                 fontWeight: FontWeight.bold,
                 color: const Color(0xFF0D47A1),
               ),
             ),
             const SizedBox(height: 16),

             TextField(
               controller: _usernameController,
               decoration: InputDecoration(
                 labelText: 'Username',
                 prefixIcon: const Icon(Icons.person),
                 border: OutlineInputBorder(
                   borderRadius: BorderRadius.circular(8),
                 ),
                 contentPadding:
                 const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
               ),
             ),
             const SizedBox(height: 12),

             TextField(
               controller: _passwordController,
               obscureText: true,
               decoration: InputDecoration(
                 labelText: 'Password',
                 prefixIcon: const Icon(Icons.lock),
                 border: OutlineInputBorder(
                   borderRadius: BorderRadius.circular(8),
                 ),
                 contentPadding:
                 const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
               ),
             ),

             if (_errorMessage.isNotEmpty) ...[
               const SizedBox(height: 12),
               Text(
                 _errorMessage,
                 style: const TextStyle(color: Colors.red),
               ),
             ],

             const SizedBox(height: 16),

             _isLoading
                 ? const CircularProgressIndicator()
                 : SizedBox(
               width: double.infinity,
               child: ElevatedButton(
                 onPressed: _handleLogin,
                 style: ElevatedButton.styleFrom(
                   backgroundColor: const Color(0xFF0D47A1),
                   foregroundColor: Colors.white,
                   padding: const EdgeInsets.symmetric(vertical: 14),
                   shape: RoundedRectangleBorder(
                     borderRadius: BorderRadius.circular(12),
                   ),
                 ),
                 child: Text(
                   'Login',
                   style: GoogleFonts.poppins(
                     fontSize: 16,
                     fontWeight: FontWeight.bold,
                   ),
                 ),
               ),
             ),

             const SizedBox(height: 8),

             TextButton(
               onPressed: () {
                 setState(() {
                   _selectedPortal = '';
                   _usernameController.clear();
                   _passwordController.clear();
                   _errorMessage = '';
                 });
               },
               child: const Text(
                 'Back to Portal Selection',
                 style: TextStyle(color: Color(0xFF0D47A1)),
               ),
             ),
           ],
         ),
       ),
     );
   }

   String _getPortalName(String portalKey) {
     switch (portalKey) {
       case 'asha_worker':
         return 'ASHA Worker';
       case 'village_leader':
         return 'Village Leader';
       case 'health_official':
         return 'Health Official';
       case 'community_member':
         return 'Community Member';
       default:
         return '';
     }
   }

   void _handleLogin() async {
     final username = _usernameController.text.trim();
     final password = _passwordController.text.trim();

     if (username.isEmpty || password.isEmpty) {
       setState(() {
         _errorMessage = 'Please enter both username and password';
       });
       return;
     }

     setState(() {
       _isLoading = true;
       _errorMessage = '';
     });

     await Future.delayed(const Duration(seconds: 1));

     if (_userCredentials[_selectedPortal] == password) {
       _navigateToDashboard();
     } else {
       setState(() {
         _errorMessage = 'Invalid credentials. Please try again.';
         _isLoading = false;
       });
     }
   }

   void _navigateToDashboard() {
     switch (_selectedPortal) {
       case 'asha_worker':
         Navigator.of(context).pushReplacement(
           MaterialPageRoute(builder: (context) => const ASHAWorkerDashboard()),
         );
         break;
       case 'village_leader':
         Navigator.of(context).pushReplacement(
           MaterialPageRoute(builder: (context) => const VillageLeaderDashboard()),
         );
         break;
       case 'health_official':
         Navigator.of(context).pushReplacement(
           MaterialPageRoute(
               builder: (context) => const HealthOfficialDashboard()),
         );
         break;
       case 'community_member':
         Navigator.of(context).pushReplacement(
           MaterialPageRoute(
               builder: (context) => const CommunityMemberDashboard()),
         );
         break;
     }
   }

   @override
   void dispose() {
     _usernameController.dispose();
     _passwordController.dispose();
     super.dispose();
   }
 }
class ASHAWorkerDashboard extends StatefulWidget {
const ASHAWorkerDashboard({super.key});

@override
State<ASHAWorkerDashboard> createState() => _ASHAWorkerDashboardState();
}

class _ASHAWorkerDashboardState extends State<ASHAWorkerDashboard> {
int _currentIndex = 0;
final PageController _pageController = PageController();

// Mock data for ASHA Worker
final List<Map<String, dynamic>> _myPatients = [
{'name': 'Rahul Sharma', 'age': 32, 'village': 'Gandhi Nagar', 'lastVisit': '2 days ago', 'status': 'Needs Follow-up'},
{'name': 'Sunita Devi', 'age': 28, 'village': 'Nehru Colony', 'lastVisit': '1 week ago', 'status': 'Stable'},
{'name': 'Amit Kumar', 'age': 45, 'village': 'Gandhi Nagar', 'lastVisit': '3 days ago', 'status': 'Recovering'},
{'name': 'Priya Singh', 'age': 22, 'village': 'Tagore Enclave', 'lastVisit': 'Today', 'status': 'New Case'},
];

final List<Map<String, dynamic>> _recentVisits = [
{'date': 'Today', 'visits': 8, 'symptoms': ['Fever', 'Diarrhea']},
{'date': 'Yesterday', 'visits': 12, 'symptoms': ['Vomiting', 'Dehydration']},
{'date': '2 days ago', 'visits': 6, 'symptoms': ['Stomach Pain', 'Fever']},
];

final List<Map<String, dynamic>> _waterTests = [
{'source': 'Village Well', 'date': 'Today', 'status': 'Moderate Risk', 'bacteria': 15},
{'source': 'River Point', 'date': 'Yesterday', 'status': 'High Risk', 'bacteria': 45},
{'source': 'Hand Pump', 'date': '3 days ago', 'status': 'Low Risk', 'bacteria': 5},
];

void _goBackToPortal() {
Navigator.of(context).pushReplacement(
MaterialPageRoute(builder: (context) => const UserPortalScreen()),
);
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
leading: IconButton(
icon: const Icon(Icons.arrow_back),
onPressed: _goBackToPortal,
),
title: Text(
'ASHA Worker Portal',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
backgroundColor: const Color(0xFF4CAF50),
foregroundColor: Colors.white,
actions: [
IconButton(
icon: const Icon(Icons.notifications),
onPressed: () {
_showASHAAlertsDialog();
},
),
IconButton(
icon: const Icon(Icons.person),
onPressed: () {
_showProfileDialog();
},
),
],
),
body: Container(
decoration: const BoxDecoration(
gradient: LinearGradient(
begin: Alignment.topCenter,
end: Alignment.bottomCenter,
colors: [
Color(0xFFE8F5E9),
Color(0xFFC8E6C9),
Color(0xFFA5D6A7),
],
),
),
child: PageView(
controller: _pageController,
onPageChanged: (index) {
setState(() {
_currentIndex = index;
});
},
children: [
_buildASHADashboard(),
_buildPatientsTab(),
_buildWaterTestingTab(),
_buildReportsTab(),
],
),
),
bottomNavigationBar: BottomNavigationBar(
currentIndex: _currentIndex,
onTap: (index) {
setState(() {
_currentIndex = index;
_pageController.jumpToPage(index);
});
},
type: BottomNavigationBarType.fixed,
selectedItemColor: const Color(0xFF4CAF50),
unselectedItemColor: Colors.grey,
items: const [
BottomNavigationBarItem(
icon: Icon(Icons.dashboard),
label: 'Dashboard',
),
BottomNavigationBarItem(
icon: Icon(Icons.people),
label: 'Patients',
),
BottomNavigationBarItem(
icon: Icon(Icons.water_drop),
label: 'Water Tests',
),
BottomNavigationBarItem(
icon: Icon(Icons.assignment),
label: 'Reports',
),
],
),
floatingActionButton: FloatingActionButton(
onPressed: () {
_showASHAQuickActions();
},
backgroundColor: const Color(0xFF4CAF50),
child: const Icon(Icons.add, color: Colors.white),
),
);
}

Widget _buildASHADashboard() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Community Health Overview',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
_buildASHAStatusCards(),
const SizedBox(height: 24),
Text(
'Recent Patient Visits',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
_buildRecentVisits(),
const SizedBox(height: 24),
Text(
'Water Test Results',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
_buildWaterTestResults(),
const SizedBox(height: 24),
Text(
'Quick Actions',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
_buildASHAQuickActions(),
],
),
),
);
}

Widget _buildASHAStatusCards() {
return Center(
child: Row(
mainAxisAlignment: MainAxisAlignment.center,
children: [
Expanded(
child: _buildStatusCard(
'Patients',
'${_myPatients.length}',
Icons.people,
const Color(0xFF4CAF50),
),
),
const SizedBox(width: 16),
Expanded(
child: _buildStatusCard(
'Today\'s Visits',
'${_recentVisits[0]['visits']}',
Icons.medical_services,
const Color(0xFF2196F3),
),
),
const SizedBox(width: 16),
Expanded(
child: _buildStatusCard(
'Water Tests',
'${_waterTests.length}',
Icons.water_drop,
const Color(0xFFFF9800),
),
),
],
),
);
}

Widget _buildStatusCard(String title, String value, IconData icon, Color color) {
return Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
Icon(icon, color: color, size: 32),
const SizedBox(height: 8),
Text(
title,
style: GoogleFonts.poppins(
fontSize: 14,
color: Colors.grey[600],
),
textAlign: TextAlign.center,
),
const SizedBox(height: 4),
Text(
value,
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: Colors.black,
),
textAlign: TextAlign.center,
),
],
),
),
);
}

Widget _buildRecentVisits() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
for (var visit in _recentVisits)
Padding(
padding: const EdgeInsets.symmetric(vertical: 8),
child: ListTile(
leading: const Icon(Icons.medical_services, color: Color(0xFF4CAF50)),
title: Text(
'${visit['visits']} visits on ${visit['date']}',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Symptoms: ${visit['symptoms'].join(', ')}',
style: GoogleFonts.poppins(),
),
),
),
],
),
),
),
);
}

Widget _buildWaterTestResults() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
for (var test in _waterTests)
Padding(
padding: const EdgeInsets.symmetric(vertical: 8),
child: ListTile(
leading: const Icon(Icons.water_drop, color: Color(0xFF2196F3)),
title: Text(
test['source'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${test['date']} - ${test['status']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
'${test['bacteria']} CFU',
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: test['status'] == 'High Risk'
? Colors.red
    : test['status'] == 'Moderate Risk'
? Colors.orange
    : Colors.green,
),
),
),
],
),
),
),
);
}

Widget _buildASHAQuickActions() {
return Center(
child: Row(
mainAxisAlignment: MainAxisAlignment.spaceAround,
children: [
_buildActionButton(Icons.person_add, 'New Patient', () {
_showNewPatientDialog();
}, const Color(0xFF4CAF50)),
_buildActionButton(Icons.medical_services, 'Symptom Report', () {
_showSymptomReportDialog();
}, const Color(0xFF2196F3)),
_buildActionButton(Icons.water_drop, 'Water Test', () {
_showWaterTestDialog();
}, const Color(0xFFFF9800)),
],
),
);
}

Widget _buildActionButton(IconData icon, String label, VoidCallback onPressed, Color color) {
return Column(
children: [
Container(
decoration: BoxDecoration(
color: color,
borderRadius: BorderRadius.circular(8),
),
child: IconButton(
icon: Icon(icon, color: Colors.white),
onPressed: onPressed,
),
),
const SizedBox(height: 6),
SizedBox(
width: 90,
child: Text(
label,
style: GoogleFonts.poppins(fontSize: 12),
textAlign: TextAlign.center,
),
),
],
);
}

Widget _buildPatientsTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'My Patients',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
..._myPatients.map((patient) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: const CircleAvatar(
backgroundColor: Color(0xFF4CAF50),
child: Icon(Icons.person, color: Colors.white),
),
title: Text(
patient['name'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${patient['age']} years • ${patient['village']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
patient['status'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: patient['status'] == 'Needs Follow-up'
? Colors.orange
    : patient['status'] == 'New Case'
? Colors.blue
    : Colors.green,
),
onTap: () {
_showPatientDetails(patient);
},
),
)).toList(),
],
),
),
);
}

Widget _buildWaterTestingTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Water Quality Testing',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.water_drop, size: 50, color: Color(0xFF2196F3)),
const SizedBox(height: 16),
Text(
'Test Water Quality',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Use your testing kit to check water sources for contamination',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_showWaterTestForm();
},
icon: const Icon(Icons.science),
label: const Text('Record Water Test'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF4CAF50),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Recent Water Tests',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
..._waterTests.map((test) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: const Icon(Icons.water_drop, color: Color(0xFF2196F3)),
title: Text(
test['source'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Tested on ${test['date']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
test['status'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: test['status'] == 'High Risk'
? Colors.red
    : test['status'] == 'Moderate Risk'
? Colors.orange
    : Colors.green,
),
),
)).toList(),
],
),
),
);
}

Widget _buildReportsTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Reports & Analytics',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF2E7D32),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.analytics, size: 50, color: Color(0xFF4CAF50)),
const SizedBox(height: 16),
Text(
'Weekly Health Report',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Summary of symptoms and cases in your assigned area',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_generateWeeklyReport();
},
icon: const Icon(Icons.download),
label: const Text('Generate Report'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF4CAF50),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.trending_up, size: 50, color: Color(0xFF2196F3)),
const SizedBox(height: 16),
Text(
'Symptom Trends',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Track symptom patterns over time',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_viewSymptomTrends();
},
icon: const Icon(Icons.show_chart),
label: const Text('View Trends'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF2196F3),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
],
),
),
);
}

void _showASHAAlertsDialog() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('ASHA Worker Alerts'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.warning, color: Colors.orange),
title: const Text('High diarrhea cases in Gandhi Nagar'),
subtitle: const Text('2 hours ago'),
onTap: () {
Navigator.of(context).pop();
// Additional action for diarrhea cases alert
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.info, color: Colors.blue),
title: const Text('Training session tomorrow'),
subtitle: const Text('5 hours ago'),
onTap: () {
Navigator.of(context).pop();
// Additional action for training session
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.medical_services, color: Colors.green),
title: const Text('New medical supplies available'),
subtitle: const Text('1 day ago'),
onTap: () {
Navigator.of(context).pop();
// Additional action for medical supplies
},
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

void _showASHAQuickActions() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Quick Actions'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.person_add, color: Colors.blue),
title: const Text('Register New Patient'),
onTap: () {
Navigator.of(context).pop();
_showNewPatientDialog();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.medical_services, color: Colors.green),
title: const Text('Record Symptoms'),
onTap: () {
Navigator.of(context).pop();
_showSymptomReportDialog();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.water_drop, color: Colors.blue),
title: const Text('Test Water Quality'),
onTap: () {
Navigator.of(context).pop();
_showWaterTestDialog();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.notifications, color: Colors.orange),
title: const Text('Send Alert'),
onTap: () {
Navigator.of(context).pop();
_sendAlert();
},
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
],
);
},
);
}

void _showNewPatientDialog() {
final _formKey = GlobalKey<FormState>();
String name = '';
String age = '';
String village = '';
String symptoms = '';

showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Register New Patient'),
content: Form(
key: _formKey,
child: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextFormField(
decoration: const InputDecoration(labelText: 'Full Name'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter name' : null,
onSaved: (v) => name = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Age'),
keyboardType: TextInputType.number,
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter age' : null,
onSaved: (v) => age = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Village'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter village' : null,
onSaved: (v) => village = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Initial Symptoms'),
maxLines: 2,
onSaved: (v) => symptoms = v!.trim(),
),
],
),
),
),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (_formKey.currentState!.validate()) {
_formKey.currentState!.save();
setState(() {
_myPatients.add({
'name': name,
'age': age,
'village': village,
'lastVisit': 'Today',
'status': 'New Case'
});
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Patient registered successfully')),
);
}
},
child: const Text('Register'),
),
],
);
},
);
}

void _showSymptomReportDialog() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Record Symptoms'),
content: const Text('Symptom recording functionality would be implemented here.'),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _showWaterTestDialog() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Test Water Quality'),
content: const Text('Water testing functionality would be implemented here.'),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _sendAlert() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Send Alert'),
content: const Text('Alert sending functionality would be implemented here.'),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _showProfileDialog() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('ASHA Worker Profile'),
content: const Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: Icon(Icons.person),
title: Text('Name: Sunita Sharma'),
),
ListTile(
leading: Icon(Icons.location_on),
title: Text('Area: Gandhi Nagar & Nehru Colony'),
),
ListTile(
leading: Icon(Icons.phone),
title: Text('Contact: 98765-43210'),
),
],
),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _showPatientDetails(Map<String, dynamic> patient) {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: Text('Patient Details: ${patient['name']}'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.person),
title: Text('Age: ${patient['age']} years'),
),
ListTile(
leading: const Icon(Icons.location_on),
title: Text('Village: ${patient['village']}'),
),
ListTile(
leading: const Icon(Icons.calendar_today),
title: Text('Last Visit: ${patient['lastVisit']}'),
),
ListTile(
leading: const Icon(Icons.medical_services),
title: Text('Status: ${patient['status']}'),
),
],
),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _showWaterTestForm() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Record Water Test'),
content: const Text('Water test form would be implemented here.'),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _generateWeeklyReport() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Weekly Report Generated'),
content: const Text('Weekly health report has been generated successfully.'),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}

void _viewSymptomTrends() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Symptom Trends'),
content: const Text('Symptom trends visualization would be shown here.'),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}
// Add this method to the _HealthOfficialDashboardState class
  void _showSendAlertDialog() {
    final Map<String, String> alertTemplates = AlertSystem.getAlertTemplates('health_official');
    String selectedTemplate = alertTemplates.keys.first;
    String customMessage = '';
    String selectedChannel = 'SMS';
    String recipientNumber = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Send Alert'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selectedTemplate,
                      items: alertTemplates.keys.map((String key) {
                        return DropdownMenuItem<String>(
                          value: key,
                          child: Text(key.replaceAll('_', ' ')),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedTemplate = newValue!;
                        });
                      },
                      decoration: const InputDecoration(labelText: 'Alert Template'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Custom Message (optional)',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                      onChanged: (value) {
                        customMessage = value;
                      },
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: selectedChannel,
                      items: ['SMS', 'WhatsApp', 'IVR Call'].map((String channel) {
                        return DropdownMenuItem<String>(
                          value: channel,
                          child: Text(channel),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedChannel = newValue!;
                        });
                      },
                      decoration: const InputDecoration(labelText: 'Channel'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Recipient Phone Number',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.phone,
                      onChanged: (value) {
                        recipientNumber = value;
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    String message = customMessage.isNotEmpty
                        ? customMessage
                        : alertTemplates[selectedTemplate]!;

                    try {
                      if (selectedChannel == 'SMS') {
                        await AlertSystem.sendSMS(message, recipientNumber);
                      } else if (selectedChannel == 'WhatsApp') {
                        await AlertSystem.sendWhatsApp(message, recipientNumber);
                      } else if (selectedChannel == 'IVR Call') {
                        await AlertSystem.makeCall(recipientNumber);
                      }

                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Alert sent via $selectedChannel')),
                      );
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Failed to send alert: $e')),
                      );
                    }
                  },
                  child: const Text('Send Alert'),
                ),
              ],
            );
          },
        );
      },
    );
  }

}
// Enhanced Village Leader Dashboard
class VillageLeaderDashboard extends StatefulWidget {
const VillageLeaderDashboard({super.key});

@override
State<VillageLeaderDashboard> createState() => _VillageLeaderDashboardState();
}

class _VillageLeaderDashboardState extends State<VillageLeaderDashboard> {
int _currentIndex = 0;
final PageController _pageController = PageController();

// Mock data for Village Leader
final Map<String, dynamic> _villageStats = {
'population': 1245,
'households': 285,
'waterSources': 6,
'healthWorkers': 3,
};

final List<Map<String, dynamic>> _villageAlerts = [
{'type': 'Water', 'message': 'Well water contamination in Sector B', 'priority': 'High', 'date': '2 hours ago'},
{'type': 'Health', 'message': 'Increased fever cases in East area', 'priority': 'Medium', 'date': '1 day ago'},
{'type': 'Infrastructure', 'message': 'Water pump repair needed in Sector C', 'priority': 'Medium', 'date': '2 days ago'},
];

final List<Map<String, dynamic>> _waterSources = [
{'name': 'Village Well', 'status': 'Contaminated', 'lastTest': 'Today', 'risk': 'High'},
{'name': 'River Point', 'status': 'Safe', 'lastTest': '2 days ago', 'risk': 'Low'},
{'name': 'Hand Pump 1', 'status': 'Safe', 'lastTest': '3 days ago', 'risk': 'Low'},
{'name': 'Hand Pump 2', 'status': 'Moderate', 'lastTest': '1 week ago', 'risk': 'Medium'},
];

// Function to go back to portal selection
void _goBackToPortal() {
Navigator.of(context).pushReplacement(
MaterialPageRoute(builder: (context) => const UserPortalScreen()),
);
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
title: Text(
'Village Leader Portal',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
backgroundColor: const Color(0xFFFF9800),
foregroundColor: Colors.white,
actions: [
IconButton(
icon: const Icon(Icons.notifications),
onPressed: () {
_showVillageAlertsDialog();
},
),
IconButton(
icon: const Icon(Icons.map),
onPressed: () {
_showVillageMap();
},
),
IconButton(
icon: const Icon(Icons.arrow_back),
onPressed: _goBackToPortal,
),
],
),
body: Container(
decoration: const BoxDecoration(
gradient: LinearGradient(
begin: Alignment.topCenter,
end: Alignment.bottomCenter,
colors: [
Color(0xFFFFF8E1),
Color(0xFFFFECB3),
Color(0xFFFFE082),
],
),
),
child: PageView(
controller: _pageController,
onPageChanged: (index) {
setState(() {
_currentIndex = index;
});
},
children: [
_buildVillageDashboard(),
_buildWaterManagementTab(),
_buildAlertsTab(),
_buildCommunityTab(),
],
),
),
bottomNavigationBar: BottomNavigationBar(
currentIndex: _currentIndex,
onTap: (index) {
setState(() {
_currentIndex = index;
_pageController.jumpToPage(index);
});
},
type: BottomNavigationBarType.fixed,
selectedItemColor: const Color(0xFFFF9800),
unselectedItemColor: Colors.grey,
items: const [
BottomNavigationBarItem(
icon: Icon(Icons.dashboard),
label: 'Dashboard',
),
BottomNavigationBarItem(
icon: Icon(Icons.water_drop),
label: 'Water',
),
BottomNavigationBarItem(
icon: Icon(Icons.warning),
label: 'Alerts',
),
BottomNavigationBarItem(
icon: Icon(Icons.people),
label: 'Community',
),
],
),
floatingActionButton: FloatingActionButton(
onPressed: () {
_showVillageQuickActions();
},
backgroundColor: const Color(0xFFFF9800),
child: const Icon(Icons.add, color: Colors.white),
),
);
}

Widget _buildVillageDashboard() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
'Village Overview',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
_buildVillageStats(),
const SizedBox(height: 24),
Text(
'Active Alerts',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
_buildActiveAlerts(),
const SizedBox(height: 24),
Text(
'Water Source Status',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
_buildWaterSourceStatus(),
const SizedBox(height: 24),
Text(
'Quick Actions',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
_buildVillageQuickActions(),
],
),
);
}

Widget _buildVillageStats() {
return GridView.count(
crossAxisCount: 2,
shrinkWrap: true,
physics: const NeverScrollableScrollPhysics(),
childAspectRatio: 1.5,
crossAxisSpacing: 16,
mainAxisSpacing: 16,
children: [
_buildStatCard('Population', '${_villageStats['population']}', Icons.people, const Color(0xFFFF9800)),
_buildStatCard('Households', '${_villageStats['households']}', Icons.home, const Color(0xFF2196F3)),
_buildStatCard('Water Sources', '${_villageStats['waterSources']}', Icons.water_drop, const Color(0xFF4CAF50)),
_buildStatCard('Health Workers', '${_villageStats['healthWorkers']}', Icons.medical_services, const Color(0xFFF44336)),
],
);
}

Widget _buildStatCard(String title, String value, IconData icon, Color color) {
return Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
Icon(icon, color: color, size: 32),
const SizedBox(height: 8),
Text(
value,
style: GoogleFonts.poppins(
fontSize: 20,
fontWeight: FontWeight.bold,
color: Colors.black,
),
),
const SizedBox(height: 4),
Text(
title,
style: GoogleFonts.poppins(
fontSize: 14,
color: Colors.grey[600],
),
textAlign: TextAlign.center,
),
],
),
),
);
}

Widget _buildActiveAlerts() {
return Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
for (var alert in _villageAlerts)
Padding(
padding: const EdgeInsets.symmetric(vertical: 8),
child: ListTile(
leading: Icon(
Icons.warning,
color: alert['priority'] == 'High' ? Colors.red : Colors.orange,
),
title: Text(
alert['message'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${alert['type']} • ${alert['date']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
alert['priority'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: alert['priority'] == 'High' ? Colors.red : Colors.orange,
),
),
),
],
),
),
);
}

Widget _buildWaterSourceStatus() {
return Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
for (var source in _waterSources)
Padding(
padding: const EdgeInsets.symmetric(vertical: 8),
child: ListTile(
leading: const Icon(Icons.water_drop, color: Color(0xFF2196F3)),
title: Text(
source['name'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Last tested: ${source['lastTest']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
source['risk'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: source['risk'] == 'High'
? Colors.red
    : source['risk'] == 'Medium'
? Colors.orange
    : Colors.green,
),
),
),
],
),
),
);
}
  Widget _buildVillageQuickActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildActionButton(Icons.warning, 'New Alert', () {
          _createNewAlert();
        }, const Color(0xFFFF9800)),
        _buildActionButton(Icons.campaign, 'Announcement', () {
          _makeAnnouncement();
        }, const Color(0xFF2196F3)),
        _buildActionButton(Icons.meeting_room, 'Call Meeting', () {
          _callCommunityMeeting();
        }, const Color(0xFF4CAF50)),
        // ADD THIS NEW BUTTON FOR ALERTS
        _buildActionButton(Icons.notifications, 'Send Alert', () {
          _showVillageAlertDialog();
        }, Colors.blue),
      ],
    );
  }

Widget _buildActionButton(IconData icon, String label, VoidCallback onPressed, Color color) {
return Column(
children: [
IconButton(
icon: Icon(icon),
onPressed: onPressed,
style: IconButton.styleFrom(
backgroundColor: color,
foregroundColor: Colors.white,
padding: const EdgeInsets.all(16),
),
),
const SizedBox(height: 4),
Text(
label,
style: GoogleFonts.poppins(fontSize: 12),
textAlign: TextAlign.center,
),
],
);
}

Widget _buildWaterManagementTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
'Water Resource Management',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.water_drop, size: 50, color: Color(0xFF2196F3)),
const SizedBox(height: 16),
Text(
'Water Source Management',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Monitor and manage village water sources',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_manageWaterSources();
},
icon: const Icon(Icons.manage_accounts),
label: const Text('Manage Sources'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFFFF9800),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Water Source Status',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
..._waterSources.map((source) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: const Icon(Icons.water_drop, color: Color(0xFF2196F3)),
title: Text(
source['name'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Status: ${source['status']} • Last tested: ${source['lastTest']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
source['risk'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: source['risk'] == 'High'
? Colors.red
    : source['risk'] == 'Medium'
? Colors.orange
    : Colors.green,
),
),
)).toList(),
],
),
);
}

Widget _buildAlertsTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
'Village Alerts & Notifications',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.warning, size: 50, color: Colors.orange),
const SizedBox(height: 16),
Text(
'Emergency Alert System',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Send alerts to community members',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_sendEmergencyAlert();
},
icon: const Icon(Icons.notification_important),
label: const Text('Send Alert'),
style: ElevatedButton.styleFrom(
backgroundColor: Colors.orange,
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Recent Alerts',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
..._villageAlerts.map((alert) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: Icon(
Icons.warning,
color: alert['priority'] == 'High' ? Colors.red : Colors.orange,
),
title: Text(
alert['message'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${alert['type']} • ${alert['date']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
alert['priority'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: alert['priority'] == 'High' ? Colors.red : Colors.orange,
),
),
)).toList(),
],
),
);
}

Widget _buildCommunityTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
'Community Management',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFEF6C00),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.people, size: 50, color: Color(0xFF4CAF50)),
const SizedBox(height: 16),
Text(
'Community Meetings',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Schedule and manage community gatherings',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_scheduleMeeting();
},
icon: const Icon(Icons.calendar_today),
label: const Text('Schedule Meeting'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFFFF9800),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.campaign, size: 50, color: Color(0xFF2196F3)),
const SizedBox(height: 16),
Text(
'Community Announcements',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Make important announcements to the village',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_makeAnnouncement();
},
icon: const Icon(Icons.campaign),
label: const Text('Make Announcement'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF2196F3),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
],
),
);
}

void _showVillageAlertsDialog() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Village Alerts'),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
for (var alert in _villageAlerts)
Column(
children: [
ListTile(
leading: Icon(
Icons.warning,
color: alert['priority'] == 'High' ? Colors.red : Colors.orange,
),
title: Text(alert['message']),
subtitle: Text('${alert['type']} • ${alert['date']}'),
),
const Divider(),
],
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

void _showVillageMap() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Village Map'),
content: SizedBox(
width: 300,
height: 300,
child: Column(
children: [
const Icon(Icons.map, size: 100, color: Colors.blue),
const SizedBox(height: 16),
const Text('Interactive village map showing:'),
const SizedBox(height: 8),
Wrap(
spacing: 8,
children: [
Chip(label: Text('${_villageStats['waterSources']} Water Sources')),
Chip(label: Text('${_villageStats['healthWorkers']} Health Workers')),
Chip(label: Text('${_villageAlerts.length} Active Alerts')),
],
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

void _showVillageQuickActions() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Village Leader Actions'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.warning, color: Colors.orange),
title: const Text('Issue Emergency Alert'),
onTap: () {
Navigator.of(context).pop();
_createNewAlert();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.campaign, color: Colors.blue),
title: const Text('Make Announcement'),
onTap: () {
Navigator.of(context).pop();
_makeAnnouncement();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.meeting_room, color: Colors.green),
title: const Text('Call Community Meeting'),
onTap: () {
Navigator.of(context).pop();
_callCommunityMeeting();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.water_drop, color: Colors.blue),
title: const Text('Manage Water Sources'),
onTap: () {
Navigator.of(context).pop();
_manageWaterSources();
},
),
],
),
);
},
);
}

void _createNewAlert() {
final TextEditingController alertController = TextEditingController();
String selectedPriority = 'Medium';
String selectedType = 'General';

showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Create New Alert'),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextField(
controller: alertController,
decoration: const InputDecoration(
labelText: 'Alert Message',
border: OutlineInputBorder(),
),
maxLines: 3,
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedType,
items: ['General', 'Water', 'Health', 'Infrastructure']
    .map((type) => DropdownMenuItem(
value: type,
child: Text(type),
))
    .toList(),
onChanged: (value) {
selectedType = value!;
},
decoration: const InputDecoration(
labelText: 'Alert Type',
border: OutlineInputBorder(),
),
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedPriority,
items: ['Low', 'Medium', 'High']
    .map((priority) => DropdownMenuItem(
value: priority,
child: Text(priority),
))
    .toList(),
onChanged: (value) {
selectedPriority = value!;
},
decoration: const InputDecoration(
labelText: 'Priority',
border: OutlineInputBorder(),
),
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (alertController.text.isNotEmpty) {
setState(() {
_villageAlerts.insert(0, {
'type': selectedType,
'message': alertController.text,
'priority': selectedPriority,
'date': 'Just now'
});
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Alert created successfully!')),
);
}
},
child: const Text('Create Alert'),
),
],
);
},
);
}

void _makeAnnouncement() {
final TextEditingController announcementController = TextEditingController();

showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Make Announcement'),
content: TextField(
controller: announcementController,
decoration: const InputDecoration(
labelText: 'Announcement Message',
border: OutlineInputBorder(),
),
maxLines: 4,
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (announcementController.text.isNotEmpty) {
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(
content: Text('Announcement sent: ${announcementController.text}'),
duration: const Duration(seconds: 3),
),
);
}
},
child: const Text('Send Announcement'),
),
],
);
},
);
}

void _callCommunityMeeting() {
final TextEditingController meetingController = TextEditingController();
DateTime selectedDate = DateTime.now();
TimeOfDay selectedTime = TimeOfDay.now();

showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Schedule Community Meeting'),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextField(
controller: meetingController,
decoration: const InputDecoration(
labelText: 'Meeting Topic',
border: OutlineInputBorder(),
),
),
const SizedBox(height: 16),
ListTile(
leading: const Icon(Icons.calendar_today),
title: const Text('Select Date'),
subtitle: Text('${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'),
onTap: () async {
final DateTime? pickedDate = await showDatePicker(
context: context,
initialDate: selectedDate,
firstDate: DateTime.now(),
lastDate: DateTime.now().add(const Duration(days: 365)),
);
if (pickedDate != null) {
selectedDate = pickedDate;
}
},
),
ListTile(
leading: const Icon(Icons.access_time),
title: const Text('Select Time'),
subtitle: Text(selectedTime.format(context)),
onTap: () async {
final TimeOfDay? pickedTime = await showTimePicker(
context: context,
initialTime: selectedTime,
);
if (pickedTime != null) {
selectedTime = pickedTime;
}
},
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (meetingController.text.isNotEmpty) {
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(
content: Text('Meeting scheduled: ${meetingController.text} on ${selectedDate.day}/${selectedDate.month}/${selectedDate.year} at ${selectedTime.format(context)}'),
duration: const Duration(seconds: 3),
),
);
}
},
child: const Text('Schedule Meeting'),
),
],
);
},
);
}

void _manageWaterSources() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Manage Water Sources'),
content: SizedBox(
width: double.maxFinite,
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
for (var source in _waterSources)
Card(
child: ListTile(
leading: const Icon(Icons.water_drop),
title: Text(source['name']),
subtitle: Text('Status: ${source['status']}'),
trailing: IconButton(
icon: const Icon(Icons.edit),
onPressed: () {
_editWaterSource(source);
},
),
),
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: _addNewWaterSource,
icon: const Icon(Icons.add),
label: const Text('Add New Water Source'),
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

void _editWaterSource(Map<String, dynamic> source) {
final TextEditingController nameController = TextEditingController(text: source['name']);
String selectedStatus = source['status'];
String selectedRisk = source['risk'];

showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Edit Water Source'),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextField(
controller: nameController,
decoration: const InputDecoration(
labelText: 'Source Name',
border: OutlineInputBorder(),
),
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedStatus,
items: ['Safe', 'Moderate', 'Contaminated']
    .map((status) => DropdownMenuItem(
value: status,
child: Text(status),
))
    .toList(),
onChanged: (value) {
selectedStatus = value!;
},
decoration: const InputDecoration(
labelText: 'Status',
border: OutlineInputBorder(),
),
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedRisk,
items: ['Low', 'Medium', 'High']
    .map((risk) => DropdownMenuItem(
value: risk,
child: Text(risk),
))
    .toList(),
onChanged: (value) {
selectedRisk = value!;
},
decoration: const InputDecoration(
labelText: 'Risk Level',
border: OutlineInputBorder(),
),
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
setState(() {
source['name'] = nameController.text;
source['status'] = selectedStatus;
source['risk'] = selectedRisk;
source['lastTest'] = 'Today';
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Water source updated!')),
);
},
child: const Text('Save Changes'),
),
],
);
},
);
}

void _addNewWaterSource() {
final TextEditingController nameController = TextEditingController();
String selectedStatus = 'Safe';
String selectedRisk = 'Low';

showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Add New Water Source'),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextField(
controller: nameController,
decoration: const InputDecoration(
labelText: 'Source Name',
border: OutlineInputBorder(),
),
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedStatus,
items: ['Safe', 'Moderate', 'Contaminated']
    .map((status) => DropdownMenuItem(
value: status,
child: Text(status),
))
    .toList(),
onChanged: (value) {
selectedStatus = value!;
},
decoration: const InputDecoration(
labelText: 'Status',
border: OutlineInputBorder(),
),
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedRisk,
items: ['Low', 'Medium', 'High']
    .map((risk) => DropdownMenuItem(
value: risk,
child: Text(risk),
))
    .toList(),
onChanged: (value) {
selectedRisk = value!;
},
decoration: const InputDecoration(
labelText: 'Risk Level',
border: OutlineInputBorder(),
),
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (nameController.text.isNotEmpty) {
setState(() {
_waterSources.add({
'name': nameController.text,
'status': selectedStatus,
'risk': selectedRisk,
'lastTest': 'Today'
});
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Water source added!')),
);
}
},
child: const Text('Add Source'),
),
],
);
},
);
}

void _sendEmergencyAlert() {
final TextEditingController alertController = TextEditingController();
String selectedPriority = 'High';

showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Send Emergency Alert'),
content: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextField(
controller: alertController,
decoration: const InputDecoration(
labelText: 'Emergency Message',
border: OutlineInputBorder(),
),
maxLines: 3,
),
const SizedBox(height: 16),
DropdownButtonFormField<String>(
value: selectedPriority,
items: ['High', 'Medium']
    .map((priority) => DropdownMenuItem(
value: priority,
child: Text(priority),
))
    .toList(),
onChanged: (value) {
selectedPriority = value!;
},
decoration: const InputDecoration(
labelText: 'Priority',
border: OutlineInputBorder(),
),
),
],
),
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (alertController.text.isNotEmpty) {
setState(() {
_villageAlerts.insert(0, {
'type': 'Emergency',
'message': alertController.text,
'priority': selectedPriority,
'date': 'Just now'
});
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Emergency alert sent!')),
);
}
},
child: const Text('Send Alert'),
),
],
);
},
);
}

void _scheduleMeeting() {
_callCommunityMeeting(); // Reuse the same functionality
}


  // Add this method to the _VillageLeaderDashboardState class
  void _showVillageAlertDialog() {
    final Map<String, String> alertTemplates = AlertSystem.getAlertTemplates('village_leader');
    String selectedTemplate = alertTemplates.keys.first;
    String customMessage = '';
    String selectedChannel = 'SMS';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Send Community Alert'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selectedTemplate,
                      items: alertTemplates.keys.map((String key) {
                        return DropdownMenuItem<String>(
                          value: key,
                          child: Text(key.replaceAll('_', ' ')),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedTemplate = newValue!;
                        });
                      },
                      decoration: const InputDecoration(labelText: 'Alert Type'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Custom Message (optional)',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                      onChanged: (value) {
                        customMessage = value;
                      },
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: selectedChannel,
                      items: ['SMS', 'WhatsApp', 'IVR Call'].map((String channel) {
                        return DropdownMenuItem<String>(
                          value: channel,
                          child: Text(channel),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedChannel = newValue!;
                        });
                      },
                      decoration: const InputDecoration(labelText: 'Channel'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    String message = customMessage.isNotEmpty
                        ? customMessage
                        : alertTemplates[selectedTemplate]!;

                    // In a real app, you would have a list of community members' numbers
                    List<String> communityNumbers = ['+911234567890', '+919876543210'];

                    try {
                      for (String number in communityNumbers) {
                        if (selectedChannel == 'SMS') {
                          await AlertSystem.sendSMS(message, number);
                        } else if (selectedChannel == 'WhatsApp') {
                          await AlertSystem.sendWhatsApp(message, number);
                        } else if (selectedChannel == 'IVR Call') {
                          await AlertSystem.makeCall(number);
                        }
                      }

                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Alert sent to community via $selectedChannel')),
                      );
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Failed to send alert: $e')),
                      );
                    }
                  },
                  child: const Text('Send to Community'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
class HealthOfficialDashboard extends StatefulWidget {
const HealthOfficialDashboard({super.key});

@override
State<HealthOfficialDashboard> createState() => _HealthOfficialDashboardState();
}

class _HealthOfficialDashboardState extends State<HealthOfficialDashboard> {
int _currentIndex = 0;
final PageController _pageController = PageController();

// Mock data for Health Official
final Map<String, dynamic> _districtStats = {
'villages': 12,
'population': 24500,
'ashaWorkers': 28,
'healthCenters': 4,
};

final List<Map<String, dynamic>> _outbreakAlerts = [
{
'id': 1,
'village': 'Gandhi Nagar',
'cases': 15,
'disease': 'Diarrhea',
'risk': 'High',
'trend': 'Increasing',
'status': 'Active'
},
{
'id': 2,
'village': 'Nehru Colony',
'cases': 8,
'disease': 'Typhoid',
'risk': 'Medium',
'trend': 'Stable',
'status': 'Active'
},
{
'id': 3,
'village': 'Tagore Enclave',
'cases': 5,
'disease': 'Cholera',
'risk': 'High',
'trend': 'Increasing',
'status': 'Active'
},
];

final List<Map<String, dynamic>> _resourceStatus = [
{'resource': 'Medicines', 'status': 'Adequate', 'level': 85},
{'resource': 'Testing Kits', 'status': 'Low', 'level': 25},
{'resource': 'Purification Tablets', 'status': 'Adequate', 'level': 70},
{'resource': 'Vaccines', 'status': 'Critical', 'level': 15},
];

// For analytics - mock time series for disease cases
final Map<String, List<int>> _diseaseTrends = {
'Diarrhea': [5, 7, 9, 12, 15],
'Typhoid': [2, 3, 4, 6, 8],
'Cholera': [0, 1, 2, 4, 5],
};

int _nextOutbreakId = 4;

@override
// ---------- UI ----------
@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
leading: IconButton(
icon: const Icon(Icons.arrow_back),
onPressed: () {
// Navigate back to portal selection screen
Navigator.of(context).pushReplacement(
MaterialPageRoute(builder: (context) => const UserPortalScreen()),
);
},
),
title: Text(
'Health Official Portal',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
backgroundColor: const Color(0xFF9C27B0),
foregroundColor: Colors.white,
actions: [
IconButton(
icon: const Icon(Icons.notifications),
onPressed: () {
_showHealthAlertsDialog();
},
),
IconButton(
icon: const Icon(Icons.analytics),
onPressed: () {
_showAdvancedAnalytics();
},
),
],
),
body: Container(
decoration: const BoxDecoration(
gradient: LinearGradient(
begin: Alignment.topCenter,
end: Alignment.bottomCenter,
colors: [
Color(0xFFF3E5F5),
Color(0xFFE1BEE7),
Color(0xFFCE93D8),
],
),
),
child: PageView(
controller: _pageController,
onPageChanged: (index) {
setState(() {
_currentIndex = index;
});
},
children: [
_buildHealthDashboard(),
_buildOutbreaksTab(),
_buildResourcesTab(),
_buildAnalyticsTab(),
],
),
),
bottomNavigationBar: BottomNavigationBar(
currentIndex: _currentIndex,
onTap: (index) {
setState(() {
_currentIndex = index;
_pageController.jumpToPage(index);
});
},
type: BottomNavigationBarType.fixed,
selectedItemColor: const Color(0xFF9C27B0),
unselectedItemColor: Colors.grey,
items: const [
BottomNavigationBarItem(
icon: Icon(Icons.dashboard),
label: 'Dashboard',
),
BottomNavigationBarItem(
icon: Icon(Icons.warning),
label: 'Outbreaks',
),
BottomNavigationBarItem(
icon: Icon(Icons.inventory),
label: 'Resources',
),
BottomNavigationBarItem(
icon: Icon(Icons.analytics),
label: 'Analytics',
),
],
),
floatingActionButton: FloatingActionButton(
onPressed: () {
_showHealthQuickActions();
},
backgroundColor: const Color(0xFF9C27B0),
child: const Icon(Icons.add, color: Colors.white),
),
);
}

// ---------- Dashboard Page ----------
Widget _buildHealthDashboard() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'District Health Overview',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
_buildDistrictStats(),
const SizedBox(height: 24),
Text(
'Active Outbreak Alerts',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
_buildOutbreakAlerts(),
const SizedBox(height: 24),
Text(
'Resource Status',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
_buildResourceStatus(),
const SizedBox(height: 24),
Text(
'Quick Actions',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
_buildHealthQuickActions(),
],
),
),
);
}

Widget _buildDistrictStats() {
return Center(
child: GridView.count(
crossAxisCount: 2,
shrinkWrap: true,
physics: const NeverScrollableScrollPhysics(),
childAspectRatio: 1.5,
crossAxisSpacing: 16,
mainAxisSpacing: 16,
children: [
_buildStatCard('Villages', '${_districtStats['villages']}', Icons.location_city, const Color(0xFF9C27B0)),
_buildStatCard('Population', '${_districtStats['population']}', Icons.people, const Color(0xFF2196F3)),
_buildStatCard('ASHA Workers', '${_districtStats['ashaWorkers']}', Icons.medical_services, const Color(0xFF4CAF50)),
_buildStatCard('Health Centers', '${_districtStats['healthCenters']}', Icons.local_hospital, const Color(0xFFF44336)),
],
),
);
}

Widget _buildStatCard(String title, String value, IconData icon, Color color) {
return Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
Icon(icon, color: color, size: 32),
const SizedBox(height: 8),
Text(
value,
style: GoogleFonts.poppins(
fontSize: 20,
fontWeight: FontWeight.bold,
color: Colors.black,
),
),
const SizedBox(height: 4),
Text(
title,
style: GoogleFonts.poppins(
fontSize: 14,
color: Colors.grey,
),
textAlign: TextAlign.center,
),
],
),
),
);
}

// ---------- Outbreak Alerts List on Dashboard ----------
Widget _buildOutbreakAlerts() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(12),
child: Column(
children: [
..._outbreakAlerts.map((alert) {
return Padding(
padding: const EdgeInsets.symmetric(vertical: 6),
child: ListTile(
onTap: () {
_openOutbreakDetails(alert);
},
leading: Icon(
Icons.warning,
color: alert['risk'] == 'High' ? Colors.red : Colors.orange,
),
title: Text(
'${alert['village']} - ${alert['disease']}',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${alert['cases']} cases • Trend: ${alert['trend']} • Status: ${alert['status']}',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
alert['risk'],
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: alert['risk'] == 'High' ? Colors.red : Colors.orange,
),
),
);
}).toList(),
const SizedBox(height: 10),
ElevatedButton.icon(
onPressed: () => _showDeclareOutbreakForm(),
icon: const Icon(Icons.add_alert),
label: const Text('Declare Outbreak'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF9C27B0),
),
),
],
),
),
),
);
}

// ---------- Resource Status on Dashboard ----------
Widget _buildResourceStatus() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(12),
child: Column(
children: [
..._resourceStatus.map((resource) {
final status = resource['status'] as String;
final level = resource['level'] as int;
final bgColor = status == 'Critical'
? Colors.red
    : status == 'Low'
? Colors.orange
    : Colors.green;
return Padding(
padding: const EdgeInsets.symmetric(vertical: 6),
child: ListTile(
onTap: () {
_showResourceDetails(resource);
},
leading: const Icon(Icons.inventory, color: Color(0xFF9C27B0)),
title: Text(
resource['resource'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Status: $status • Level: $level%',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
'$level%',
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: bgColor,
),
),
);
}).toList(),
const SizedBox(height: 10),
ElevatedButton.icon(
onPressed: () => _orderResources(),
icon: const Icon(Icons.add_shopping_cart),
label: const Text('Order Resource'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF2196F3),
),
),
],
),
),
),
);
}

  Widget _buildHealthQuickActions() {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildActionButton(Icons.warning, 'Outbreak Alert', () {
            _showDeclareOutbreakForm();
          }, const Color(0xFF9C27B0)),
          _buildActionButton(Icons.inventory, 'Order Resources', () {
            _orderResources();
          }, const Color(0xFF2196F3)),
          _buildActionButton(Icons.assignment, 'Generate Report', () {
            _generateHealthReport();
          }, const Color(0xFF4CAF50)),
          // CORRECTED: This button should call _showSendAlertDialog()
          _buildActionButton(Icons.notifications, 'Send Alert', () {
            _showSendAlertDialog();
          }, Colors.orange),
        ],
      ),
    );
  }

// Add this method to the _HealthOfficialDashboardState class
  void _showSendAlertDialog() {
    final Map<String, String> alertTemplates = AlertSystem.getAlertTemplates('health_official');
    String selectedTemplate = alertTemplates.keys.first;
    String customMessage = '';
    String selectedChannel = 'SMS';
    String recipientNumber = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Send Alert'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selectedTemplate,
                      items: alertTemplates.keys.map((String key) {
                        return DropdownMenuItem<String>(
                          value: key,
                          child: Text(key.replaceAll('_', ' ')),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedTemplate = newValue!;
                        });
                      },
                      decoration: const InputDecoration(labelText: 'Alert Template'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Custom Message (optional)',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                      onChanged: (value) {
                        customMessage = value;
                      },
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: selectedChannel,
                      items: ['SMS', 'WhatsApp', 'IVR Call'].map((String channel) {
                        return DropdownMenuItem<String>(
                          value: channel,
                          child: Text(channel),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedChannel = newValue!;
                        });
                      },
                      decoration: const InputDecoration(labelText: 'Channel'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Recipient Phone Number',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.phone,
                      onChanged: (value) {
                        recipientNumber = value;
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    String message = customMessage.isNotEmpty
                        ? customMessage
                        : alertTemplates[selectedTemplate]!;

                    try {
                      if (selectedChannel == 'SMS') {
                        await AlertSystem.sendSMS(message, recipientNumber);
                      } else if (selectedChannel == 'WhatsApp') {
                        await AlertSystem.sendWhatsApp(message, recipientNumber);
                      } else if (selectedChannel == 'IVR Call') {
                        await AlertSystem.makeCall(recipientNumber);
                      }

                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Alert sent via $selectedChannel')),
                      );
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Failed to send alert: $e')),
                      );
                    }
                  },
                  child: const Text('Send Alert'),
                ),
              ],
            );
          },
        );
      },
    );
  }

Widget _buildActionButton(IconData icon, String label, VoidCallback onPressed, Color color) {
return Column(
children: [
Container(
decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
child: IconButton(
icon: Icon(icon, color: Colors.white),
onPressed: onPressed,
tooltip: label,
),
),
const SizedBox(height: 6),
SizedBox(
width: 90,
child: Text(
label,
style: GoogleFonts.poppins(fontSize: 12),
textAlign: TextAlign.center,
),
),
],
);
}

// ---------- Outbreaks Tab ----------
Widget _buildOutbreaksTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Disease Outbreak Management',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.warning, size: 50, color: Colors.red),
const SizedBox(height: 16),
Text(
'Outbreak Response',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Manage and respond to disease outbreaks',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_manageOutbreakResponse();
},
icon: const Icon(Icons.emergency),
label: const Text('Outbreak Response'),
style: ElevatedButton.styleFrom(
backgroundColor: Colors.red,
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Active Outbreaks',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
..._outbreakAlerts.map((alert) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
onTap: () {
_openOutbreakDetails(alert);
},
leading: Icon(
Icons.warning,
color: alert['risk'] == 'High' ? Colors.red : Colors.orange,
),
title: Text(
'${alert['village']} - ${alert['disease']}',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${alert['cases']} cases • Trend: ${alert['trend']} • Status: ${alert['status']}',
style: GoogleFonts.poppins(),
),
trailing: PopupMenuButton<String>(
onSelected: (value) {
if (value == 'resolve') {
_resolveOutbreak(alert['id']);
} else if (value == 'respond') {
_markInResponse(alert['id']);
}
},
itemBuilder: (_) => [
const PopupMenuItem(value: 'respond', child: Text('Mark In Response')),
const PopupMenuItem(value: 'resolve', child: Text('Mark Resolved')),
],
),
),
)).toList(),
],
),
),
);
}

// ---------- Resources Tab ----------
Widget _buildResourcesTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Resource Management',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.inventory, size: 50, color: Color(0xFF9C27B0)),
const SizedBox(height: 16),
Text(
'Resource Allocation',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Manage and allocate health resources',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_allocateResources();
},
icon: const Icon(Icons.dashboard),
label: const Text('Allocate Resources'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF9C27B0),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Current Resource Status',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
..._resourceStatus.map((resource) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
onTap: () => _showResourceDetails(resource),
leading: const Icon(Icons.inventory, color: Color(0xFF9C27B0)),
title: Text(
resource['resource'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Status: ${resource['status']} • Level: ${resource['level']}%',
style: GoogleFonts.poppins(),
),
trailing: Chip(
label: Text(
'${resource['level']}%',
style: const TextStyle(color: Colors.white, fontSize: 12),
),
backgroundColor: resource['status'] == 'Critical'
? Colors.red
    : resource['status'] == 'Low'
? Colors.orange
    : Colors.green,
),
),
)).toList(),
],
),
),
);
}

// ---------- Analytics Tab ----------
Widget _buildAnalyticsTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Health Analytics & Reports',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFF7B1FA2),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.analytics, size: 50, color: Color(0xFF2196F3)),
const SizedBox(height: 16),
Text(
'District Health Report',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Generate comprehensive health reports',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_generateDistrictReport();
},
icon: const Icon(Icons.description),
label: const Text('Generate Report'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF2196F3),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
],
),
),
),
const SizedBox(height: 24),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.trending_up, size: 50, color: Color(0xFF4CAF50)),
const SizedBox(height: 16),
Text(
'Disease Trends',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Analyze disease patterns and trends',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
const SizedBox(height: 16),
ElevatedButton.icon(
onPressed: () {
_analyzeDiseaseTrends();
},
icon: const Icon(Icons.show_chart),
label: const Text('View Trends'),
style: ElevatedButton.styleFrom(
backgroundColor: const Color(0xFF4CAF50),
foregroundColor: Colors.white,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
),
),
const SizedBox(height: 16),
_buildTrendsPreview(),
],
),
),
),
],
),
),
);
}

Widget _buildTrendsPreview() {
// Simple textual trend preview; you can swap with fl_chart visual
return Column(
children: _diseaseTrends.entries.map((entry) {
final disease = entry.key;
final series = entry.value;
final latest = series.isNotEmpty ? series.last : 0;
return ListTile(
leading: const Icon(Icons.timeline),
title: Text(disease, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
subtitle: Text('Recent cases: $latest • Series: ${series.join(', ')}'),
trailing: ElevatedButton(
onPressed: () {
_showTrendDetail(disease, series);
},
child: const Text('Open'),
),
);
}).toList(),
);
}

// ---------- Dialogs & Actions Implementation ----------

// Health Alerts Dialog (top-right bell)
void _showHealthAlertsDialog() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Health Department Alerts'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.warning, color: Colors.red),
title: const Text('Cholera outbreak in Tagore Enclave'),
subtitle: const Text('Immediate intervention required'),
trailing: TextButton(
child: const Text('Respond'),
onPressed: () {
Navigator.of(context).pop();
// find and mark Tagore Enclave in response
final found = _outbreakAlerts.where((a) => a['village'] == 'Tagore Enclave');
if (found.isNotEmpty) _markInResponse(found.first['id']);
},
),
),
const Divider(),
ListTile(
leading: const Icon(Icons.info, color: Colors.blue),
title: const Text('Resource delivery tomorrow'),
subtitle: const Text('Prepare storage facilities'),
),
const Divider(),
ListTile(
leading: const Icon(Icons.medical_services, color: Colors.green),
title: const Text('Training session for ASHA workers'),
subtitle: const Text('Schedule for next week'),
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

// Advanced analytics button (top-right)
void _showAdvancedAnalytics() {
// For now navigate to analytics page
setState(() {
_currentIndex = 3;
_pageController.jumpToPage(3);
});
}

// Quick actions FAB -> dialog with action choices
void _showHealthQuickActions() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Health Official Actions'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.warning, color: Colors.red),
title: const Text('Declare Outbreak'),
onTap: () {
Navigator.of(context).pop();
_showDeclareOutbreakForm();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.inventory, color: Colors.blue),
title: const Text('Order Resources'),
onTap: () {
Navigator.of(context).pop();
_orderResources();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.assignment, color: Colors.green),
title: const Text('Generate Report'),
onTap: () {
Navigator.of(context).pop();
_generateHealthReport();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.analytics, color: Colors.purple),
title: const Text('View Analytics'),
onTap: () {
Navigator.of(context).pop();
setState(() {
_currentIndex = 3;
_pageController.jumpToPage(3);
});
},
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
],
);
},
);
}

// ---------- Declare Outbreak Form ----------
void _showDeclareOutbreakForm() {
final _formKey = GlobalKey<FormState>();
String village = '';
String disease = '';
int cases = 1;
String risk = 'Medium';
String trend = 'Stable';

showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Declare New Outbreak'),
content: Form(
key: _formKey,
child: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextFormField(
decoration: const InputDecoration(labelText: 'Village'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter village' : null,
onSaved: (v) => village = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Disease'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter disease' : null,
onSaved: (v) => disease = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Number of Cases'),
keyboardType: TextInputType.number,
initialValue: '1',
validator: (v) {
final n = int.tryParse(v ?? '');
if (n == null || n <= 0) return 'Enter valid cases';
return null;
},
onSaved: (v) => cases = int.parse(v!),
),
DropdownButtonFormField<String>(
value: risk,
items: const ['Low', 'Medium', 'High'].map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
onChanged: (v) => risk = v ?? 'Medium',
decoration: const InputDecoration(labelText: 'Risk Level'),
),
DropdownButtonFormField<String>(
value: trend,
items: const ['Decreasing', 'Stable', 'Increasing'].map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
onChanged: (v) => trend = v ?? 'Stable',
decoration: const InputDecoration(labelText: 'Trend'),
),
],
),
),
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
ElevatedButton(
onPressed: () {
if (_formKey.currentState!.validate()) {
_formKey.currentState!.save();
setState(() {
_outbreakAlerts.insert(0, {
'id': _nextOutbreakId++,
'village': village,
'disease': disease,
'cases': cases,
'risk': risk,
'trend': trend,
'status': 'Active'
});
// update trend data mock
_diseaseTrends.putIfAbsent(disease, () => []);
_diseaseTrends[disease]!.add(cases);
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Outbreak declared')));
}
},
child: const Text('Declare'),
),
],
);
},
);
}

// ---------- Outbreak details ----------
void _openOutbreakDetails(Map<String, dynamic> alert) {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: Text('${alert['village']} — ${alert['disease']}'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
Text('Cases: ${alert['cases']}'),
Text('Risk: ${alert['risk']}'),
Text('Trend: ${alert['trend']}'),
Text('Status: ${alert['status']}'),
const SizedBox(height: 12),
ElevatedButton.icon(
onPressed: () {
Navigator.of(context).pop();
_markInResponse(alert['id']);
},
icon: const Icon(Icons.local_hospital),
label: const Text('Mark In Response'),
style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
),
const SizedBox(height: 8),
ElevatedButton.icon(
onPressed: () {
Navigator.of(context).pop();
_resolveOutbreak(alert['id']);
},
icon: const Icon(Icons.check),
label: const Text('Mark Resolved'),
style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
),
],
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
],
);
},
);
}

// Mark outbreak in response
void _markInResponse(int id) {
setState(() {
final idx = _outbreakAlerts.indexWhere((a) => a['id'] == id);
if (idx != -1) {
_outbreakAlerts[idx]['status'] = 'In Response';
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Marked In Response')));
}
});
}

// Resolve outbreak
void _resolveOutbreak(int id) {
setState(() {
final idx = _outbreakAlerts.indexWhere((a) => a['id'] == id);
if (idx != -1) {
_outbreakAlerts[idx]['status'] = 'Resolved';
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Outbreak resolved')));
}
});
}

// ---------- Resource ordering & details ----------
void _orderResources() {
// Simple dialog to order a resource and increase its level
String? selectedResource;
int quantity = 10;

showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Order Resources'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
DropdownButtonFormField<String>(
items: _resourceStatus.map((r) => r['resource'] as String).map((rname) => DropdownMenuItem(value: rname, child: Text(rname))).toList(),
value: _resourceStatus.first['resource'] as String,
onChanged: (v) => selectedResource = v,
decoration: const InputDecoration(labelText: 'Select Resource'),
),
TextFormField(
initialValue: '10',
keyboardType: TextInputType.number,
decoration: const InputDecoration(labelText: 'Quantity (approx to increase %)'),
onChanged: (v) {
final n = int.tryParse(v) ?? 10;
quantity = n;
},
),
],
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
ElevatedButton(
onPressed: () {
final resourceName = selectedResource ?? _resourceStatus.first['resource'] as String;
setState(() {
final idx = _resourceStatus.indexWhere((r) => r['resource'] == resourceName);
if (idx != -1) {
var current = _resourceStatus[idx]['level'] as int;
current = (current + quantity).clamp(0, 100);
_resourceStatus[idx]['level'] = current;
// update status field
_resourceStatus[idx]['status'] = current <= 15 ? 'Critical' : (current <= 40 ? 'Low' : 'Adequate');
}
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order placed and resource updated')));
},
child: const Text('Order'),
),
],
);
},
);
}

void _showResourceDetails(Map<String, dynamic> resource) {
showDialog(
context: context,
builder: (context) {
int adjust = 0;
return AlertDialog(
title: Text(resource['resource']),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
Text('Current Level: ${resource['level']}%'),
const SizedBox(height: 8),
TextFormField(
keyboardType: TextInputType.number,
decoration: const InputDecoration(labelText: 'Adjust level by (+/-)'),
initialValue: '0',
onChanged: (v) {
adjust = int.tryParse(v) ?? 0;
},
),
],
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
ElevatedButton(
onPressed: () {
setState(() {
final idx = _resourceStatus.indexWhere((r) => r['resource'] == resource['resource']);
if (idx != -1) {
var newLevel = (_resourceStatus[idx]['level'] as int) + adjust;
newLevel = newLevel.clamp(0, 100);
_resourceStatus[idx]['level'] = newLevel;
_resourceStatus[idx]['status'] = newLevel <= 15 ? 'Critical' : (newLevel <= 40 ? 'Low' : 'Adequate');
}
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Resource updated')));
},
child: const Text('Update'),
),
],
);
},
);
}

// ---------- Allocate resources flow (from Resources Tab) ----------
void _allocateResources() {
showDialog(
context: context,
builder: (context) {
final Map<String, int> allocation = {};
for (var r in _resourceStatus) allocation[r['resource']] = 0;

return StatefulBuilder(builder: (context, setStateDialog) {
return AlertDialog(
title: const Text('Allocate Resources'),
content: SingleChildScrollView(
child: Column(
children: _resourceStatus.map((r) {
final name = r['resource'] as String;
return Row(
children: [
Expanded(child: Text(name)),
SizedBox(
width: 90,
child: TextFormField(
initialValue: '0',
keyboardType: TextInputType.number,
decoration: const InputDecoration(labelText: 'Qty %'),
onChanged: (v) {
allocation[name] = int.tryParse(v) ?? 0;
},
),
)
],
);
}).toList(),
),
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
ElevatedButton(
onPressed: () {
setState(() {
allocation.forEach((name, qty) {
final idx = _resourceStatus.indexWhere((r) => r['resource'] == name);
if (idx != -1 && qty != 0) {
final int current = _resourceStatus[idx]['level'] as int;
final newLevel = (current + qty).clamp(0, 100);
_resourceStatus[idx]['level'] = newLevel;
_resourceStatus[idx]['status'] = newLevel <= 15 ? 'Critical' : (newLevel <= 40 ? 'Low' : 'Adequate');
}
});
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Resources allocated')));
},
child: const Text('Allocate'),
),
],
);
});
},
);
}

// ---------- Generate report (quick in-app summary) ----------
void _generateHealthReport() {
final outbreaks = _outbreakAlerts.where((a) => a['status'] != 'Resolved').length;
final criticalResources = _resourceStatus.where((r) => r['status'] == 'Critical').length;

final report = StringBuffer();
report.writeln('=== District Health Report ===');
report.writeln('Villages: ${_districtStats['villages']}');
report.writeln('Population: ${_districtStats['population']}');
report.writeln('ASHA Workers: ${_districtStats['ashaWorkers']}');
report.writeln('Health Centers: ${_districtStats['healthCenters']}');
report.writeln('');
report.writeln('Active Outbreaks: $outbreaks');
for (var a in _outbreakAlerts) {
report.writeln('- ${a['village']}: ${a['disease']} (${a['cases']} cases) [${a['status']}]');
}
report.writeln('');
report.writeln('Resource Status:');
for (var r in _resourceStatus) {
report.writeln('- ${r['resource']}: ${r['level']}% (${r['status']})');
}
report.writeln('');
report.writeln('Critical resources count: $criticalResources');
final reportText = report.toString();

showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Health Report'),
content: SingleChildScrollView(child: Text(reportText)),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
ElevatedButton(
onPressed: () {
// Optional: export to PDF or share
// If you added pdf + printing packages, create a PDF here and print/share.
// Example (pseudo):
// final pdfDoc = pw.Document();
// pdfDoc.addPage(pw.Page(build: (c) => pw.Text(reportText)));
// Printing.layoutPdf(onLayout: (p) => pdfDoc.save());
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Report generated (view)')));
},
child: const Text('Export (optional)'),
),
],
);
},
);
}

// District level report (more official)
void _generateDistrictReport() {
_generateHealthReport();
}

// ---------- Manage Outbreak response (opens quick action sheet) ----------
void _manageOutbreakResponse() {
if (_outbreakAlerts.isEmpty) {
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No outbreaks to manage')));
return;
}
// Open a selector for outbreaks and choose actions
showDialog(
context: context,
builder: (context) {
Map? chosen;
return StatefulBuilder(builder: (context, setStateDialog) {
return AlertDialog(
title: const Text('Manage Outbreak Response'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
DropdownButton<Map>(
isExpanded: true,
hint: const Text('Select outbreak'),
value: chosen,
items: _outbreakAlerts.map((o) {
return DropdownMenuItem<Map>(value: o, child: Text('${o['village']} — ${o['disease']} (${o['status']})'));
}).toList(),
onChanged: (val) {
setStateDialog(() {
chosen = val;
});
},
),
const SizedBox(height: 8),
ElevatedButton.icon(
onPressed: chosen == null
? null
    : () {
// simulate sending team
setState(() {
chosen!['status'] = 'In Response';
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Medical team dispatched')));
},
icon: const Icon(Icons.local_shipping),
label: const Text('Send Medical Team'),
),
const SizedBox(height: 8),
ElevatedButton.icon(
onPressed: chosen == null
? null
    : () {
setState(() {
chosen!['status'] = 'Awareness Campaign';
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Awareness campaign scheduled')));
},
icon: const Icon(Icons.campaign),
label: const Text('Schedule Awareness'),
),
const SizedBox(height: 8),
ElevatedButton.icon(
onPressed: chosen == null
? null
    : () {
setState(() {
chosen!['status'] = 'Testing Scheduled';
});
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Testing scheduled')));
},
icon: const Icon(Icons.biotech),
label: const Text('Schedule Testing'),
),
],
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
],
);
});
},
);
}

// ---------- Analyze Disease Trends ----------
void _analyzeDiseaseTrends() {
setState(() {
_currentIndex = 3;
_pageController.jumpToPage(3);
});
// Optionally perform trend computations here (not required for demo)
}

void _showTrendDetail(String disease, List<int> series) {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: Text('$disease Trend'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
Text('Series: ${series.join(', ')}'),
const SizedBox(height: 8),
Text('Latest: ${series.isNotEmpty ? series.last : 0}'),
const SizedBox(height: 8),
const Text('(Replace this section with a fl_chart line chart for a nicer visual)'),
],
),
actions: [
TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
],
);
},
);
}

// ---------- Helper: Show outbreak details and allow resolve/respond ----------
void _showOutbreakOptions(Map<String, dynamic> outbreak) {
_openOutbreakDetails(outbreak);
}
}
class CommunityMemberDashboard extends StatefulWidget {
const CommunityMemberDashboard({super.key});

@override
State<CommunityMemberDashboard> createState() => _CommunityMemberDashboardState();
}

class _CommunityMemberDashboardState extends State<CommunityMemberDashboard> {
int _currentIndex = 0;
final PageController _pageController = PageController();

// Mock data for Community Member
final List<Map<String, dynamic>> _communityAlerts = [
{'type': 'Water', 'message': 'Boil water before use in Sector B', 'priority': 'High', 'date': '2 hours ago'},
{'type': 'Health', 'message': 'Free health check-up camp tomorrow', 'priority': 'Medium', 'date': '1 day ago'},
{'type': 'General', 'message': 'Community meeting on Sunday', 'priority': 'Low', 'date': '2 days ago'},
];

final List<Map<String, dynamic>> _waterSourceInfo = [
{'name': 'Village Well', 'status': 'Unsafe', 'advice': 'Boil before use'},
{'name': 'River Point', 'status': 'Safe', 'advice': 'Safe for drinking'},
{'name': 'Hand Pump 1', 'status': 'Safe', 'advice': 'Safe for drinking'},
{'name': 'Hand Pump 2', 'status': 'Moderate', 'advice': 'Filter before use'},
];

final List<Map<String, dynamic>> _healthTips = [
{'title': 'Safe Water Practices', 'content': 'Always boil or filter water before drinking'},
{'title': 'Hand Hygiene', 'content': 'Wash hands with soap before eating and after using toilet'},
{'title': 'Food Safety', 'content': 'Cook food thoroughly and eat while fresh'},
{'title': 'Symptom Reporting', 'content': 'Report any health symptoms to ASHA worker immediately'},
];

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
leading: IconButton(
icon: const Icon(Icons.arrow_back),
onPressed: () {
// Navigate back to portal selection screen
Navigator.of(context).pushReplacement(
MaterialPageRoute(builder: (context) => const UserPortalScreen()),
);
},
),
title: Text(
'Community Portal',
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
backgroundColor: const Color(0xFFF44336),
foregroundColor: Colors.white,
actions: [
IconButton(
icon: const Icon(Icons.notifications),
onPressed: () {
_showCommunityAlertsDialog();
},
),
IconButton(
icon: const Icon(Icons.help),
onPressed: () {
_showHelpDialog();
},
)
],
),
body: Container(
decoration: const BoxDecoration(
gradient: LinearGradient(
begin: Alignment.topCenter,
end: Alignment.bottomCenter,
colors: [
Color(0xFFFFEBEE),
Color(0xFFFFCDD2),
Color(0xFFEF9A9A),
],
),
),
child: PageView(
controller: _pageController,
onPageChanged: (index) {
setState(() {
_currentIndex = index;
});
},
children: [
_buildCommunityDashboard(),
_buildAlertsTab(),
_buildWaterInfoTab(),
_buildHealthInfoTab(),
],
),
),
bottomNavigationBar: BottomNavigationBar(
currentIndex: _currentIndex,
onTap: (index) {
setState(() {
_currentIndex = index;
_pageController.jumpToPage(index);
});
},
type: BottomNavigationBarType.fixed,
selectedItemColor: const Color(0xFFF44336),
unselectedItemColor: Colors.grey,
items: const [
BottomNavigationBarItem(
icon: Icon(Icons.dashboard),
label: 'Dashboard',
),
BottomNavigationBarItem(
icon: Icon(Icons.warning),
label: 'Alerts',
),
BottomNavigationBarItem(
icon: Icon(Icons.water_drop),
label: 'Water Info',
),
BottomNavigationBarItem(
icon: Icon(Icons.health_and_safety),
label: 'Health Info',
),
],
),
floatingActionButton: FloatingActionButton(
onPressed: () {
_showCommunityQuickActions();
},
backgroundColor: const Color(0xFFF44336),
child: const Icon(Icons.add, color: Colors.white),
),
);
}

Widget _buildCommunityDashboard() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Community Information',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
_buildCommunityStatus(),
const SizedBox(height: 24),
Text(
'Recent Alerts',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
_buildRecentAlerts(),
const SizedBox(height: 24),
Text(
'Water Source Status',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
_buildWaterSourceStatus(),
const SizedBox(height: 24),
Text(
'Quick Actions',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
_buildCommunityQuickActions(),
],
),
),
);
}

Widget _buildCommunityStatus() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: const Padding(
padding: EdgeInsets.all(16),
child: Column(
children: [
Icon(Icons.people, size: 50, color: Color(0xFFF44336)),
SizedBox(height: 16),
Text(
'Community Health Status',
style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
),
SizedBox(height: 8),
Text(
'No active outbreaks in your area',
style: TextStyle(fontSize: 16, color: Colors.green),
textAlign: TextAlign.center,
),
SizedBox(height: 8),
Text(
'Stay informed about water safety and health alerts',
textAlign: TextAlign.center,
),
],
),
),
),
);
}

Widget _buildRecentAlerts() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
for (var alert in _communityAlerts)
Padding(
padding: const EdgeInsets.symmetric(vertical: 8),
child: ListTile(
leading: Icon(
Icons.warning,
color: alert['priority'] == 'High' ? Colors.red :
alert['priority'] == 'Medium' ? Colors.orange : Colors.blue,
),
title: Text(
alert['message'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${alert['type']} • ${alert['date']}',
style: GoogleFonts.poppins(),
),
),
),
],
),
),
),
);
}

Widget _buildWaterSourceStatus() {
return Center(
child: Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
for (var source in _waterSourceInfo)
Padding(
padding: const EdgeInsets.symmetric(vertical: 8),
child: ListTile(
leading: const Icon(Icons.water_drop, color: Color(0xFF2196F3)),
title: Text(
source['name'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Status: ${source['status']} • ${source['advice']}',
style: GoogleFonts.poppins(),
),
trailing: Icon(
source['status'] == 'Unsafe' ? Icons.warning : Icons.check_circle,
color: source['status'] == 'Unsafe' ? Colors.red : Colors.green,
),
),
),
],
),
),
),
);
}

Widget _buildCommunityQuickActions() {
return Center(
child: Row(
mainAxisAlignment: MainAxisAlignment.spaceAround,
children: [
_buildActionButton(Icons.report, 'Report Symptoms', () {
_reportSymptoms();
}, const Color(0xFFF44336)),
_buildActionButton(Icons.water_drop, 'Water Concern', () {
_reportWaterConcern();
}, const Color(0xFF2196F3)),
_buildActionButton(Icons.help, 'Get Help', () {
_getHelp();
}, const Color(0xFF4CAF50)),
],
),
);
}

Widget _buildActionButton(IconData icon, String label, VoidCallback onPressed, Color color) {
return Column(
children: [
Container(
decoration: BoxDecoration(
color: color,
borderRadius: BorderRadius.circular(8),
),
child: IconButton(
icon: Icon(icon, color: Colors.white),
onPressed: onPressed,
),
),
const SizedBox(height: 6),
SizedBox(
width: 90,
child: Text(
label,
style: GoogleFonts.poppins(fontSize: 12),
textAlign: TextAlign.center,
),
),
],
);
}

Widget _buildAlertsTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Community Alerts',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.notifications_active, size: 50, color: Color(0xFFF44336)),
const SizedBox(height: 16),
Text(
'Emergency Alerts',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Important notifications for your community',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Recent Alerts',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
..._communityAlerts.map((alert) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: Icon(
Icons.warning,
color: alert['priority'] == 'High' ? Colors.red :
alert['priority'] == 'Medium' ? Colors.orange : Colors.blue,
),
title: Text(
alert['message'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'${alert['type']} • ${alert['date']}',
style: GoogleFonts.poppins(),
),
),
)).toList(),
],
),
),
);
}


Widget _buildWaterInfoTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Water Safety Information',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.water_drop, size: 50, color: Color(0xFF2196F3)), // Fixed: Icles -> Icons
const SizedBox(height: 16),
Text(
'Water Source Status',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Current status of water sources in your area',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Water Sources',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
..._waterSourceInfo.map((source) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: const Icon(Icons.water_drop, color: Color(0xFF2196F3)),
title: Text(
source['name'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(
'Status: ${source['status']} • ${source['advice']}',
style: GoogleFonts.poppins(),
),
trailing: Icon(
source['status'] == 'Unsafe' ? Icons.warning : Icons.check_circle,
color: source['status'] == 'Unsafe' ? Colors.red : Colors.green,
),
),
)).toList(),
],
),
),
);
}

Widget _buildHealthInfoTab() {
return SingleChildScrollView(
padding: const EdgeInsets.all(16),
child: Center(
child: Column(
children: [
Text(
'Health Information',
style: GoogleFonts.poppins(
fontSize: 22,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
child: Padding(
padding: const EdgeInsets.all(16),
child: Column(
children: [
const Icon(Icons.health_and_safety, size: 50, color: Color(0xFF4CAF50)),
const SizedBox(height: 16),
Text(
'Health Tips & Guidance',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
),
),
const SizedBox(height: 8),
Text(
'Important health information for your family',
style: GoogleFonts.poppins(),
textAlign: TextAlign.center,
),
],
),
),
),
const SizedBox(height: 24),
Text(
'Health Tips',
style: GoogleFonts.poppins(
fontSize: 18,
fontWeight: FontWeight.bold,
color: const Color(0xFFD32F2F),
),
),
const SizedBox(height: 16),
..._healthTips.map((tip) => Card(
elevation: 4,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
margin: const EdgeInsets.only(bottom: 16),
child: ListTile(
leading: const Icon(Icons.lightbulb, color: Color(0xFFFFC107)),
title: Text(
tip['title'],
style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
),
subtitle: Text(tip['content']),
),
)).toList(),
],
),
),
);
}

void _showCommunityAlertsDialog() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Community Alerts'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.warning, color: Colors.red),
title: const Text('Boil water before use in Sector B'),
subtitle: const Text('Due to contamination concerns'),
onTap: () {
Navigator.of(context).pop();
// Additional action if needed
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.info, color: Colors.blue),
title: const Text('Free health camp tomorrow'),
subtitle: const Text('At community center, 10 AM - 4 PM'),
onTap: () {
Navigator.of(context).pop();
// Additional action if needed
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.people, color: Colors.green),
title: const Text('Community meeting on Sunday'),
subtitle: const Text('Discuss water safety measures'),
onTap: () {
Navigator.of(context).pop();
// Additional action if needed
},
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

void _showHelpDialog() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Need Help?'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.medical_services, color: Colors.green),
title: const Text('Contact ASHA Worker'),
subtitle: const Text('For health concerns and symptoms'),
onTap: () {
Navigator.of(context).pop();
_getHelp();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.people, color: Colors.blue),
title: const Text('Contact Village Leader'),
subtitle: const Text('For community issues and alerts'),
onTap: () {
Navigator.of(context).pop();
_getHelp();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.emergency, color: Colors.red),
title: const Text('Emergency Services'),
subtitle: const Text('Call 108 for medical emergencies'),
onTap: () {
Navigator.of(context).pop();
_getHelp();
},
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Close'),
),
],
);
},
);
}

void _showCommunityQuickActions() {
showDialog(
context: context,
builder: (BuildContext context) {
return AlertDialog(
title: const Text('Community Actions'),
content: Column(
mainAxisSize: MainAxisSize.min,
children: [
ListTile(
leading: const Icon(Icons.report, color: Colors.red),
title: const Text('Report Symptoms'),
onTap: () {
Navigator.of(context).pop();
_reportSymptoms();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.water_drop, color: Colors.blue),
title: const Text('Report Water Concern'),
onTap: () {
Navigator.of(context).pop();
_reportWaterConcern();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.help, color: Colors.green),
title: const Text('Get Help'),
onTap: () {
Navigator.of(context).pop();
_getHelp();
},
),
const Divider(),
ListTile(
leading: const Icon(Icons.info, color: Colors.purple),
title: const Text('View Health Tips'),
onTap: () {
Navigator.of(context).pop();
setState(() {
_currentIndex = 3;
_pageController.jumpToPage(3);
});
},
),
],
),
actions: [
TextButton(
onPressed: () {
Navigator.of(context).pop();
},
child: const Text('Cancel'),
),
],
);
},
);
}

void _reportSymptoms() {
showDialog(
context: context,
builder: (context) {
final _formKey = GlobalKey<FormState>();
String name = '';
String symptoms = '';
String duration = '';

return AlertDialog(
title: const Text('Report Symptoms'),
content: Form(
key: _formKey,
child: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextFormField(
decoration: const InputDecoration(labelText: 'Your Name'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter your name' : null,
onSaved: (v) => name = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Symptoms'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Describe symptoms' : null,
onSaved: (v) => symptoms = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Duration'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter duration' : null,
onSaved: (v) => duration = v!.trim(),
),
],
),
),
),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (_formKey.currentState!.validate()) {
_formKey.currentState!.save();
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Symptoms reported successfully')),
);
}
},
child: const Text('Submit'),
),
],
);
},
);
}

void _reportWaterConcern() {
showDialog(
context: context,
builder: (context) {
final _formKey = GlobalKey<FormState>();
String location = '';
String concern = '';

return AlertDialog(
title: const Text('Report Water Concern'),
content: Form(
key: _formKey,
child: SingleChildScrollView(
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
TextFormField(
decoration: const InputDecoration(labelText: 'Location'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter location' : null,
onSaved: (v) => location = v!.trim(),
),
TextFormField(
decoration: const InputDecoration(labelText: 'Concern Description'),
validator: (v) => (v == null || v.trim().isEmpty) ? 'Describe the concern' : null,
onSaved: (v) => concern = v!.trim(),
maxLines: 3,
),
],
),
),
),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Cancel'),
),
ElevatedButton(
onPressed: () {
if (_formKey.currentState!.validate()) {
_formKey.currentState!.save();
Navigator.of(context).pop();
ScaffoldMessenger.of(context).showSnackBar(
const SnackBar(content: Text('Water concern reported successfully')),
);
}
},
child: const Text('Submit'),
),
],
);
},
);
}

void _getHelp() {
showDialog(
context: context,
builder: (context) {
return AlertDialog(
title: const Text('Get Help'),
content: const Column(
mainAxisSize: MainAxisSize.min,
children: [
Text('Contact information for assistance:'),
SizedBox(height: 16),
ListTile(
leading: Icon(Icons.phone, color: Colors.green),
title: Text('ASHA Worker: 98765-43210'),
),
ListTile(
leading: Icon(Icons.phone, color: Colors.blue),
title: Text('Health Center: 0123-456789'),
),
ListTile(
leading: Icon(Icons.phone, color: Colors.red),
title: Text('Emergency: 108'),
),
],
),
actions: [
TextButton(
onPressed: () => Navigator.of(context).pop(),
child: const Text('Close'),
),
],
);
},
);
}
}
 // Add this import at the top of your file with other imports

